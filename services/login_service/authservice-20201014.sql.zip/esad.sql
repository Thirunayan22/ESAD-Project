-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 14, 2020 at 01:21 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `esad`
--

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `personal_access_tokens`
--

INSERT INTO `personal_access_tokens` (`id`, `tokenable_type`, `tokenable_id`, `name`, `token`, `abilities`, `last_used_at`, `created_at`, `updated_at`) VALUES
(37, 'App\\Models\\User', 3, 'mobile', '1a1b1a19957b26279bb1c01d8f023f6d713e266ade74b3c18da3df42bbc49d63', '[\"*\"]', NULL, '2020-10-11 00:35:21', '2020-10-11 00:35:21'),
(38, 'App\\Models\\User', 1, 'mobile', '8aebfecc3d647c8a30f7af191b101dd1ed8717c67c4082eebbe66349e465d0aa', '[\"*\"]', '2020-10-11 01:46:27', '2020-10-11 01:12:02', '2020-10-11 01:46:27'),
(42, 'App\\Models\\User', 4, 'mobile', '5ab47f6b098ff5fc62a658bdc3fee3214aa61b1f16962a06904cc08aadc47498', '[\"*\"]', '2020-10-11 05:07:15', '2020-10-11 05:06:25', '2020-10-11 05:07:15'),
(43, 'App\\Models\\User', 5, 'mobile', '5df24cc2b4608005703049e1657ae1f82c5a446a4d6074b3a6d69b92987265dd', '[\"*\"]', '2020-10-11 05:15:29', '2020-10-11 05:07:53', '2020-10-11 05:15:29'),
(44, 'App\\Models\\User', 5, 'mobile', 'bad9fc64d6d12dd0b9701e482cc03d9c4c1fc9f8315b4dd9a533f0383dc3dcff', '[\"*\"]', NULL, '2020-10-11 07:17:56', '2020-10-11 07:17:56'),
(45, 'App\\Models\\User', 1, 'mobile', '46f6593fa98b5d67a1f766d0cf296edf1e7ddf53bbd4e8d5693c0da3dbd9ea9d', '[\"*\"]', '2020-10-11 10:52:16', '2020-10-11 07:18:07', '2020-10-11 10:52:16'),
(46, 'App\\Models\\User', 1, 'mobile', '74292b5b0930553e69dff4d589431167b3dfb5cb8ca3d51a2be31de5c28b19bc', '[\"*\"]', NULL, '2020-10-11 07:33:51', '2020-10-11 07:33:51'),
(47, 'App\\Models\\User', 21, 'mobile', '645e17a1e53341f3a08f1e42055895b41f4de626857e52ec764abf311a0c8514', '[\"*\"]', '2020-10-11 10:54:32', '2020-10-11 10:52:29', '2020-10-11 10:54:32'),
(48, 'App\\Models\\User', 1, 'mobile', '0cdb29a439fd2798a880ac9cb89c73f566aee32b43b07e4b07f81df3d7cb5ccd', '[\"*\"]', '2020-10-12 17:34:22', '2020-10-11 10:54:40', '2020-10-12 17:34:22'),
(49, 'App\\Models\\User', 5, 'mobile', 'c58f5eb5817968a031321ca44ee151b0243c976f83d517070ae8c0c855c2d47b', '[\"*\"]', NULL, '2020-10-11 10:55:43', '2020-10-11 10:55:43'),
(50, 'App\\Models\\User', 21, 'mobile', 'cf1bf62acbdd28d08c1981b1220c7a43a51ed2a618d9d17456dafcdbc5d87fde', '[\"*\"]', NULL, '2020-10-11 10:56:05', '2020-10-11 10:56:05'),
(51, 'App\\Models\\User', 21, 'mobile', 'e436a425cf7b87753ef6353b039f32b384305d1f2a73dc54c6f7ca536349d1fc', '[\"*\"]', '2020-10-13 17:31:15', '2020-10-12 17:36:17', '2020-10-13 17:31:15'),
(52, 'App\\Models\\User', 5, 'mobile', '4fce8d459c4904a7e66d6d134a39eba4a7b8bae1926720374b0a809d1ab308ba', '[\"*\"]', '2020-10-13 17:33:04', '2020-10-13 17:32:06', '2020-10-13 17:33:04'),
(54, 'App\\Models\\User', 24, 'mobile', '5da5d035ba37c8b654e6fbed3acadba826d2b5b081bb677ccfa5efca0a916473', '[\"*\"]', NULL, '2020-10-13 17:46:22', '2020-10-13 17:46:22'),
(55, 'App\\Models\\User', 24, 'mobile', '71e676cee4086464b8cf78012313547190e1ea198430b12f2e0c4b5f50087f35', '[\"*\"]', NULL, '2020-10-13 17:46:26', '2020-10-13 17:46:26');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) NOT NULL,
  `role_name` varchar(50) NOT NULL COMMENT 'name of the user role',
  `created_at` datetime NOT NULL COMMENT 'record created date',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT 'record updated date and time'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `role_name`, `created_at`, `updated_at`) VALUES
(1, 'admin', '0000-00-00 00:00:00', '2020-10-07 15:10:41'),
(2, 'admin_assist', '0000-00-00 00:00:00', '2020-10-07 15:10:19'),
(3, 'seller', '0000-00-00 00:00:00', '2020-10-07 15:10:19'),
(4, 'buyer', '0000-00-00 00:00:00', '2020-10-07 15:10:19');

-- --------------------------------------------------------

--
-- Table structure for table `seller_details`
--

CREATE TABLE `seller_details` (
  `id` bigint(20) UNSIGNED NOT NULL COMMENT 'Auto Increment number',
  `user_id` bigint(20) NOT NULL COMMENT 'user_id FK to users Table',
  `verify_status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '1- verified , 0 - not verified',
  `document` varchar(255) NOT NULL COMMENT 'base64 document',
  `created_at` datetime NOT NULL COMMENT 'record created date time',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT 'record updated date time'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `seller_details`
--

INSERT INTO `seller_details` (`id`, `user_id`, `verify_status`, `document`, `created_at`, `updated_at`) VALUES
(1, 5, 0, 'SADVASVAV', '2020-10-11 10:45:29', '2020-10-13 00:10:02');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) NOT NULL,
  `role_id` bigint(20) NOT NULL COMMENT 'foreign key to role id',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `role_id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 3, 'nuwan ishara123', 'abce@gmail.com', NULL, '$2y$10$Xeu2i6iJdOK8NEyWI9cQz.HI4n9b5o8GaJQ0TfisWOkJqWaReeUW6', NULL, '2020-10-12 17:12:18', '2020-10-12 17:12:18'),
(5, 3, 'nuwan ishara', 'abca@gmail.com', NULL, '$2y$10$R1DZ4rgli.FYxgQRtXryn.ThqoyLBzPBnFT8jjhnylWwIX22wZT32', NULL, '2020-10-11 05:07:53', '2020-10-11 05:07:53'),
(21, 2, 'nuwan ishara', 'abcd@gmail.com', NULL, '$2y$10$QNaqKxDbXEOf4Zr8pjTgLOjUt4dT4pyNYB0hHdxm133/6LYfHiGdy', NULL, '2020-10-11 07:40:00', '2020-10-11 07:40:00'),
(22, 4, 'nuwan ishara', 'abcf@gmail.com', NULL, '$2y$10$vMl0mEiVlEO8unS3U3Z4kOFMBi/43J5jtwxa1a9VXsrLa.9hbfZna', NULL, '2020-10-11 10:55:03', '2020-10-11 10:55:03'),
(24, 4, 'nuwan ishara', 'buyer@gmail.com', NULL, '$2y$10$FLEHw7/iIsYvTQDP7Yw7WuLyTQiEWhcT2XH1jeIX/JpocimGNDIx2', NULL, '2020-10-13 17:46:22', '2020-10-13 17:46:22');

-- --------------------------------------------------------

--
-- Table structure for table `user_activities`
--

CREATE TABLE `user_activities` (
  `id` bigint(20) NOT NULL COMMENT 'Log ID (Auto Increment)',
  `uidx` bigint(20) DEFAULT NULL COMMENT 'User Index ID',
  `user_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `activity` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Funcation user did',
  `url` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Current URL',
  `controller_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'user access controller FK to controller table',
  `action_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'user perform action FK to action table',
  `parameters` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'URL Parameters',
  `status` int(11) NOT NULL COMMENT 'success-1,fail - 0',
  `ip_addr` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'IP Address ',
  `date_time` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Date and time of the activity',
  `time_diff` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'difference of login and logout',
  `imi` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'mobile imi number',
  `dev_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'mobile device name',
  `ua_browser` text COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'User''s Web Browser',
  `latitude` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'mobile gps location latitude',
  `longitude` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'mobile gps location longitude',
  `modified_at` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'updated at'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_activities`
--

INSERT INTO `user_activities` (`id`, `uidx`, `user_name`, `activity`, `url`, `controller_name`, `action_name`, `parameters`, `status`, `ip_addr`, `date_time`, `time_diff`, `imi`, `dev_name`, `ua_browser`, `latitude`, `longitude`, `modified_at`) VALUES
(1, 1, NULL, 'INVALID_DATA_TYPE', 'http://127.0.0.1:8000/api/roles/byname/admin', 'App\\Http\\Controllers\\Auth\\RolesController', 'getByName', 'http://127.0.0.1:8000/api/roles/byname/admin', 0, '127.0.0.1', '2020-10-11 01:46:07', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 07:16:07'),
(2, 1, NULL, 'INVALID_DATA_TYPE', 'http://127.0.0.1:8000/api/roles/byname/admin', 'App\\Http\\Controllers\\Auth\\RolesController', 'getByName', 'http://127.0.0.1:8000/api/roles/byname/admin', 0, '127.0.0.1', '2020-10-11 01:46:07', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 07:16:07'),
(3, 1, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/roles/byname/admin', 'App\\Http\\Controllers\\Auth\\RolesController', 'getByName', 'http://127.0.0.1:8000/api/roles/byname/admin', 1, '127.0.0.1', '2020-10-11 01:46:27', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 07:16:27'),
(4, NULL, NULL, 'view data of the given role buyer', 'http://127.0.0.1:8000/api/register/seller', 'App\\Http\\Controllers\\Auth\\AuthController', 'registerSeller', 'http://127.0.0.1:8000/api/register/seller', 1, '127.0.0.1', '2020-10-11 01:50:58', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 07:20:58'),
(5, NULL, NULL, 'view data of the given role buyer', 'http://127.0.0.1:8000/api/register/seller', 'App\\Http\\Controllers\\Auth\\AuthController', 'registerSeller', 'http://127.0.0.1:8000/api/register/seller', 1, '127.0.0.1', '2020-10-11 01:52:18', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 07:22:18'),
(6, NULL, NULL, 'view data of the given role buyer', 'http://127.0.0.1:8000/api/register/seller', 'App\\Http\\Controllers\\Auth\\AuthController', 'registerSeller', 'http://127.0.0.1:8000/api/register/seller', 1, '127.0.0.1', '2020-10-11 01:52:34', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 07:22:34'),
(7, NULL, NULL, 'view data of the given role buyer', 'http://127.0.0.1:8000/api/register/seller', 'App\\Http\\Controllers\\Auth\\AuthController', 'registerSeller', 'http://127.0.0.1:8000/api/register/seller', 1, '127.0.0.1', '2020-10-11 01:53:08', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 07:23:08'),
(8, NULL, NULL, 'view data of the given role buyer', 'http://127.0.0.1:8000/api/register/seller', 'App\\Http\\Controllers\\Auth\\AuthController', 'registerSeller', 'http://127.0.0.1:8000/api/register/seller', 1, '127.0.0.1', '2020-10-11 01:54:00', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 07:24:00'),
(10, 4, NULL, 'USER_NOT_A_SELLER', 'http://127.0.0.1:8000/api/register/verify', 'App\\Http\\Controllers\\Auth\\AuthController', 'verifySeller', 'http://127.0.0.1:8000/api/register/verify', 0, '127.0.0.1', '2020-10-11 05:06:41', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 10:36:41'),
(12, NULL, NULL, 'view data of the given role seller', 'http://127.0.0.1:8000/api/register/seller', 'App\\Http\\Controllers\\Auth\\AuthController', 'registerSeller', 'http://127.0.0.1:8000/api/register/seller', 1, '127.0.0.1', '2020-10-11 05:07:53', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 10:37:53'),
(15, 5, NULL, 'SQLSTATE[HY000]: General error: 1364 Field \'verify_status\' doesn\'t have a default value (SQL: insert into `seller_details` (`user_id`, `document`, `created_at`, `updated_at`) values (5, nuwan ishara, 2020-10-11 10:42:50, 2020-10-11 10:42:50))', 'http://127.0.0.1:8000/api/register/verify', 'App\\Http\\Controllers\\Auth\\AuthController', 'verifySeller', 'http://127.0.0.1:8000/api/register/verify', 0, '127.0.0.1', '2020-10-11 05:12:50', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 10:42:50'),
(18, 5, NULL, 'view data of the given role seller', 'http://127.0.0.1:8000/api/register/verify', 'App\\Http\\Controllers\\Auth\\AuthController', 'verifySeller', 'http://127.0.0.1:8000/api/register/verify', 1, '127.0.0.1', '2020-10-11 05:15:29', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 10:45:29'),
(19, 5, NULL, 'serller verification step 2 completed: 5', 'http://127.0.0.1:8000/api/register/verify', 'App\\Http\\Controllers\\Auth\\AuthController', 'verifySeller', 'http://127.0.0.1:8000/api/register/verify', 1, '127.0.0.1', '2020-10-11 05:15:29', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 10:45:29'),
(20, 1, NULL, 'User created: nuwan ishara', 'http://127.0.0.1:8000/api/usermgt/create', 'App\\Http\\Controllers\\Admin\\AdminController', 'adminAssistCreate', 'http://127.0.0.1:8000/api/usermgt/create', 1, '127.0.0.1', '2020-10-11 07:25:03', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 12:55:03'),
(24, 1, NULL, 'User created: nuwan ishara', 'http://127.0.0.1:8000/api/usermgt/create', 'App\\Http\\Controllers\\Admin\\AdminController', 'adminAssistCreate', 'http://127.0.0.1:8000/api/usermgt/create', 1, '127.0.0.1', '2020-10-11 07:27:43', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 12:57:43'),
(43, 1, NULL, 'User created: nuwan ishara', 'http://127.0.0.1:8000/api/usermgt/create', 'App\\Http\\Controllers\\Admin\\AdminController', 'adminAssistCreate', 'http://127.0.0.1:8000/api/usermgt/create', 1, '127.0.0.1', '2020-10-11 07:40:00', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 13:10:00'),
(44, 1, NULL, 'view data of the given role 2', 'http://127.0.0.1:8000/api/usermgt/create', 'App\\Http\\Controllers\\Admin\\AdminController', 'adminAssistCreate', 'http://127.0.0.1:8000/api/usermgt/create', 1, '127.0.0.1', '2020-10-11 07:40:00', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 13:10:00'),
(45, 1, NULL, 'Trying to get property \'role_id\' of non-object', 'http://127.0.0.1:8000/api/usermgt/create', 'App\\Http\\Controllers\\Admin\\AdminController', 'adminAssistCreate', 'http://127.0.0.1:8000/api/usermgt/create', 0, '127.0.0.1', '2020-10-11 07:44:36', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 13:14:36'),
(65, 1, NULL, 'ACCESS_DENIED', 'http://127.0.0.1:8000/api/usermgt/create', 'App\\Http\\Controllers\\Admin\\AdminController', 'adminAssistCreate', 'http://127.0.0.1:8000/api/usermgt/create', 0, '127.0.0.1', '2020-10-11 10:51:10', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:21:10'),
(66, 1, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:51:50', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:21:50'),
(67, 1, NULL, 'view data of the given role admin_assist', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:51:50', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:21:50'),
(68, 1, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:51:50', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:21:50'),
(69, 1, NULL, 'view data of the given role admin_assist', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:51:50', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:21:50'),
(70, 1, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:51:50', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:21:50'),
(71, 1, NULL, 'view all data users', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:51:50', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:21:50'),
(72, 1, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:52:16', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:22:16'),
(73, 1, NULL, 'view data of the given role admin_assist', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:52:16', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:22:16'),
(74, 1, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:52:16', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:22:16'),
(75, 1, NULL, 'view data of the given role admin_assist', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:52:16', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:22:16'),
(76, 1, NULL, 'view all data users', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:52:16', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:22:16'),
(77, 21, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:52:43', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:22:43'),
(78, 21, NULL, 'view data of the given role admin_assist', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:52:43', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:22:43'),
(79, 21, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:52:43', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:22:43'),
(80, 21, NULL, 'view data of the given role admin_assist', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:52:43', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:22:43'),
(81, 21, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:52:43', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:22:43'),
(82, 21, NULL, 'view all data users', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:52:43', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:22:43'),
(83, 21, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:54:06', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:24:06'),
(84, 21, NULL, 'view data of the given role admin_assist', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:54:06', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:24:06'),
(85, 21, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:54:06', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:24:06'),
(86, 21, NULL, 'view data of the given role admin_assist', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:54:06', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:24:06'),
(87, 21, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:54:06', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:24:06'),
(88, 21, NULL, 'view all data users', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:54:06', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:24:06'),
(90, 21, NULL, 'ACCESS_DENIED', 'http://127.0.0.1:8000/api/usermgt/create', 'App\\Http\\Controllers\\Admin\\AdminController', 'adminAssistCreate', 'http://127.0.0.1:8000/api/usermgt/create', 0, '127.0.0.1', '2020-10-11 10:54:32', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:24:32'),
(92, 1, NULL, 'EMAIL_ALREADY_IN_USE', 'http://127.0.0.1:8000/api/usermgt/create', 'App\\Http\\Controllers\\Admin\\AdminController', 'adminAssistCreate', 'http://127.0.0.1:8000/api/usermgt/create', 0, '127.0.0.1', '2020-10-11 10:54:54', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:24:54'),
(93, 1, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/create', 'App\\Http\\Controllers\\Admin\\AdminController', 'adminAssistCreate', 'http://127.0.0.1:8000/api/usermgt/create', 1, '127.0.0.1', '2020-10-11 10:55:03', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:25:03'),
(94, 1, NULL, 'User created: nuwan ishara', 'http://127.0.0.1:8000/api/usermgt/create', 'App\\Http\\Controllers\\Admin\\AdminController', 'adminAssistCreate', 'http://127.0.0.1:8000/api/usermgt/create', 1, '127.0.0.1', '2020-10-11 10:55:03', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:25:03'),
(95, 1, NULL, 'view data of the given role 4', 'http://127.0.0.1:8000/api/usermgt/create', 'App\\Http\\Controllers\\Admin\\AdminController', 'adminAssistCreate', 'http://127.0.0.1:8000/api/usermgt/create', 1, '127.0.0.1', '2020-10-11 10:55:03', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:25:03'),
(97, 1, NULL, 'EMAIL_ALREADY_IN_USE', 'http://127.0.0.1:8000/api/usermgt/create', 'App\\Http\\Controllers\\Admin\\AdminController', 'adminAssistCreate', 'http://127.0.0.1:8000/api/usermgt/create', 0, '127.0.0.1', '2020-10-11 10:58:41', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:28:41'),
(98, 1, NULL, 'view data of the given role 22', 'http://127.0.0.1:8000/api/usermgt/users/byid/22', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUserById', 'http://127.0.0.1:8000/api/usermgt/users/byid/22', 1, '127.0.0.1', '2020-10-11 11:03:06', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:33:06'),
(99, 1, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-12 09:51:27', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 15:21:27'),
(100, 1, NULL, 'view data of the given role admin_assist', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-12 09:51:27', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 15:21:27'),
(101, 1, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-12 09:51:27', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 15:21:27'),
(102, 1, NULL, 'view data of the given role admin_assist', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-12 09:51:28', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 15:21:28'),
(103, 1, NULL, 'view all data users', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-12 09:51:28', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 15:21:28'),
(104, 1, NULL, 'view data of the given role 22', 'http://127.0.0.1:8000/api/usermgt/users/byid/22', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUserById', 'http://127.0.0.1:8000/api/usermgt/users/byid/22', 1, '127.0.0.1', '2020-10-12 09:51:36', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 15:21:36'),
(105, 1, NULL, 'User update name: nuwan ishara123', 'http://127.0.0.1:8000/api/usermgt/update/22', 'App\\Http\\Controllers\\Admin\\AdminController', 'adminAssistUpdate', 'http://127.0.0.1:8000/api/usermgt/update/22', 1, '127.0.0.1', '2020-10-12 17:12:05', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 22:42:05'),
(106, 1, NULL, 'view data of the given role 4', 'http://127.0.0.1:8000/api/usermgt/update/22', 'App\\Http\\Controllers\\Admin\\AdminController', 'adminAssistUpdate', 'http://127.0.0.1:8000/api/usermgt/update/22', 1, '127.0.0.1', '2020-10-12 17:12:05', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 22:42:05'),
(107, 1, NULL, 'User update name: nuwan ishara123', 'http://127.0.0.1:8000/api/usermgt/update/22', 'App\\Http\\Controllers\\Admin\\AdminController', 'adminAssistUpdate', 'http://127.0.0.1:8000/api/usermgt/update/22', 1, '127.0.0.1', '2020-10-12 17:12:18', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 22:42:18'),
(108, 1, NULL, 'view data of the given role 3', 'http://127.0.0.1:8000/api/usermgt/update/22', 'App\\Http\\Controllers\\Admin\\AdminController', 'adminAssistUpdate', 'http://127.0.0.1:8000/api/usermgt/update/22', 1, '127.0.0.1', '2020-10-12 17:12:18', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 22:42:18'),
(114, 21, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/verify/1', 'App\\Http\\Controllers\\Admin\\AdminController', 'verifySellerByAdmin', 'http://127.0.0.1:8000/api/usermgt/verify/1', 1, '127.0.0.1', '2020-10-12 17:37:11', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 23:07:11'),
(115, 21, NULL, 'view data of the given role admin_assist', 'http://127.0.0.1:8000/api/usermgt/verify/1', 'App\\Http\\Controllers\\Admin\\AdminController', 'verifySellerByAdmin', 'http://127.0.0.1:8000/api/usermgt/verify/1', 1, '127.0.0.1', '2020-10-12 17:37:11', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 23:07:11'),
(116, 21, NULL, 'admin verification step 2 completed: 21', 'http://127.0.0.1:8000/api/usermgt/verify/1', 'App\\Http\\Controllers\\Admin\\AdminController', 'verifySellerByAdmin', 'http://127.0.0.1:8000/api/usermgt/verify/1', 1, '127.0.0.1', '2020-10-12 17:37:11', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 23:07:11'),
(121, 21, NULL, 'The given data was invalid.', 'http://127.0.0.1:8000/api/usermgt/verify/1', 'App\\Http\\Controllers\\Admin\\AdminController', 'verifySellerByAdmin', 'http://127.0.0.1:8000/api/usermgt/verify/1', 0, '127.0.0.1', '2020-10-12 17:38:17', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 23:08:17'),
(144, 21, NULL, 'The given data was invalid.', 'http://127.0.0.1:8000/api/usermgt/verify/1', 'App\\Http\\Controllers\\Admin\\AdminController', 'verifySellerByAdmin', 'http://127.0.0.1:8000/api/usermgt/verify/1', 0, '127.0.0.1', '2020-10-12 18:07:24', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 23:37:24'),
(149, 21, NULL, 'The given data was invalid.', 'http://127.0.0.1:8000/api/usermgt/verify/1', 'App\\Http\\Controllers\\Admin\\AdminController', 'verifySellerByAdmin', 'http://127.0.0.1:8000/api/usermgt/verify/1', 0, '127.0.0.1', '2020-10-12 18:13:08', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 23:43:08'),
(152, 21, NULL, 'ACCESS_DENIED', 'http://127.0.0.1:8000/api/usermgt/verify/1', 'App\\Http\\Controllers\\Admin\\AdminController', 'verifySellerByAdmin', 'http://127.0.0.1:8000/api/usermgt/verify/1', 0, '127.0.0.1', '2020-10-12 18:13:30', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 23:43:30'),
(159, 21, NULL, 'ACCESS_DENIED', 'http://127.0.0.1:8000/api/usermgt/verify/1', 'App\\Http\\Controllers\\Admin\\AdminController', 'verifySellerByAdmin', 'http://127.0.0.1:8000/api/usermgt/verify/1', 0, '127.0.0.1', '2020-10-12 18:19:48', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 23:49:48'),
(162, 21, NULL, 'ACCESS_DENIED', 'http://127.0.0.1:8000/api/usermgt/verify/1', 'App\\Http\\Controllers\\Admin\\AdminController', 'verifySellerByAdmin', 'http://127.0.0.1:8000/api/usermgt/verify/1', 0, '127.0.0.1', '2020-10-12 18:20:09', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 23:50:09'),
(165, 21, NULL, 'ACCESS_DENIED', 'http://127.0.0.1:8000/api/usermgt/verify/1', 'App\\Http\\Controllers\\Admin\\AdminController', 'verifySellerByAdmin', 'http://127.0.0.1:8000/api/usermgt/verify/1', 0, '127.0.0.1', '2020-10-12 18:20:27', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 23:50:27'),
(168, 21, NULL, 'ACCESS_DENIED', 'http://127.0.0.1:8000/api/usermgt/verify/1', 'App\\Http\\Controllers\\Admin\\AdminController', 'verifySellerByAdmin', 'http://127.0.0.1:8000/api/usermgt/verify/1', 0, '127.0.0.1', '2020-10-12 18:21:03', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 23:51:03'),
(171, 21, NULL, 'The given data was invalid.', 'http://127.0.0.1:8000/api/usermgt/verify/1', 'App\\Http\\Controllers\\Admin\\AdminController', 'verifySellerByAdmin', 'http://127.0.0.1:8000/api/usermgt/verify/1', 0, '127.0.0.1', '2020-10-12 18:21:33', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 23:51:33'),
(172, 21, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/verify/1', 'App\\Http\\Controllers\\Admin\\AdminController', 'verifySellerByAdmin', 'http://127.0.0.1:8000/api/usermgt/verify/1', 1, '127.0.0.1', '2020-10-12 18:21:41', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 23:51:41'),
(173, 21, NULL, 'view data of the given role admin_assist', 'http://127.0.0.1:8000/api/usermgt/verify/1', 'App\\Http\\Controllers\\Admin\\AdminController', 'verifySellerByAdmin', 'http://127.0.0.1:8000/api/usermgt/verify/1', 1, '127.0.0.1', '2020-10-12 18:21:41', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 23:51:41'),
(174, 21, NULL, 'admin verification step 2 completed: 21', 'http://127.0.0.1:8000/api/usermgt/verify/1', 'App\\Http\\Controllers\\Admin\\AdminController', 'verifySellerByAdmin', 'http://127.0.0.1:8000/api/usermgt/verify/1', 1, '127.0.0.1', '2020-10-12 18:21:41', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 23:51:41'),
(181, 21, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-12 18:43:07', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-13 00:13:07'),
(182, 21, NULL, 'view data of the given role admin_assist', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-12 18:43:07', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-13 00:13:07'),
(183, 21, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-12 18:43:07', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-13 00:13:07'),
(184, 21, NULL, 'view data of the given role admin_assist', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-12 18:43:07', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-13 00:13:07'),
(185, 21, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-12 18:43:07', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-13 00:13:07'),
(186, 21, NULL, 'view all data users', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-12 18:43:07', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-13 00:13:07'),
(187, 21, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-12 18:44:10', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-13 00:14:10'),
(188, 21, NULL, 'view data of the given role admin_assist', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-12 18:44:10', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-13 00:14:10'),
(189, 21, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-12 18:44:10', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-13 00:14:10'),
(190, 21, NULL, 'view data of the given role admin_assist', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-12 18:44:10', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-13 00:14:10'),
(191, 21, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-12 18:44:10', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-13 00:14:10'),
(192, 21, NULL, 'view all data users', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-12 18:44:10', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-13 00:14:10'),
(207, 21, NULL, 'ACCESS_DENIED', 'http://127.0.0.1:8000/api/register/verify', 'App\\Http\\Controllers\\Auth\\AuthController', 'verifySeller', 'http://127.0.0.1:8000/api/register/verify', 0, '127.0.0.1', '2020-10-13 17:31:15', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-13 23:01:15'),
(209, 5, NULL, 'CANNOT_FIND_VERIFICATION_DETAILS', 'http://127.0.0.1:8000/api/register/verify', 'App\\Http\\Controllers\\Auth\\AuthController', 'getVerifySellerStatus', 'http://127.0.0.1:8000/api/register/verify', 0, '127.0.0.1', '2020-10-13 17:32:37', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-13 23:02:37'),
(212, NULL, NULL, 'Trying to get property \'role_id\' of non-object', 'http://127.0.0.1:8000/api/register/buyer', 'App\\Http\\Controllers\\Auth\\AuthController', 'registerBuyer', 'http://127.0.0.1:8000/api/register/buyer', 0, '127.0.0.1', '2020-10-13 17:42:15', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-13 23:12:15'),
(214, NULL, NULL, 'view data of the given role buyer', 'http://127.0.0.1:8000/api/register/buyer', 'App\\Http\\Controllers\\Auth\\AuthController', 'registerBuyer', 'http://127.0.0.1:8000/api/register/buyer', 1, '127.0.0.1', '2020-10-13 17:46:22', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-13 23:16:22');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `seller_details`
--
ALTER TABLE `seller_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `role_id` (`role_id`);

--
-- Indexes for table `user_activities`
--
ALTER TABLE `user_activities`
  ADD PRIMARY KEY (`id`),
  ADD KEY `UIDX` (`uidx`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `seller_details`
--
ALTER TABLE `seller_details`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Auto Increment number', AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `user_activities`
--
ALTER TABLE `user_activities`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Log ID (Auto Increment)', AUTO_INCREMENT=215;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `seller_details`
--
ALTER TABLE `seller_details`
  ADD CONSTRAINT `seller_details_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
