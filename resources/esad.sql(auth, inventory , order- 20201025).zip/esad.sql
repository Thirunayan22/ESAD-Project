-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 24, 2020 at 08:31 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `esad`
--

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inv_invoice`
--

CREATE TABLE `inv_invoice` (
  `id` bigint(20) NOT NULL COMMENT 'A',
  `buyer_id` bigint(20) NOT NULL COMMENT 'Related User Account Number',
  `complete_status` int(2) NOT NULL COMMENT 'invoice 1 completed (1-complete, 2-pending,3- cancelled by buyer, 4 cancelled by seller)',
  `total_amount` double NOT NULL COMMENT 'invoice total amount',
  `payment_procedure` int(2) NOT NULL COMMENT '1-visa, 2- cash on delivery',
  `paid_status` int(2) NOT NULL COMMENT '1-full paid, 2-partially paid, 3-unpaid',
  `delivery_date` datetime DEFAULT NULL COMMENT 'date of delivery',
  `created_at` datetime NOT NULL COMMENT 'Record created date',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Record modified date time'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `inv_invoice`
--

INSERT INTO `inv_invoice` (`id`, `buyer_id`, `complete_status`, `total_amount`, `payment_procedure`, `paid_status`, `delivery_date`, `created_at`, `updated_at`) VALUES
(1, 24, 1, 255, 2, 1, NULL, '2020-10-24 02:53:26', '2020-10-24 05:11:48'),
(2, 24, 2, 255, 1, 1, NULL, '2020-10-24 03:06:52', '2020-10-23 21:36:52');

-- --------------------------------------------------------

--
-- Table structure for table `inv_items`
--

CREATE TABLE `inv_items` (
  `id` bigint(20) NOT NULL,
  `inv_id` bigint(20) NOT NULL COMMENT 'Invoice id FK to Invoice table',
  `product_id` bigint(20) NOT NULL COMMENT 'Product id FK to pr_product table	',
  `quantity` double NOT NULL COMMENT 'Item quantity',
  `unit_price` double NOT NULL COMMENT 'Unit price',
  `discount_amount` double DEFAULT NULL COMMENT 'Discount amount',
  `total_price` double NOT NULL COMMENT 'Total amount',
  `created_at` datetime NOT NULL COMMENT 'Record Created at',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT 'Record Updated at'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `inv_items`
--

INSERT INTO `inv_items` (`id`, `inv_id`, `product_id`, `quantity`, `unit_price`, `discount_amount`, `total_price`, `created_at`, `updated_at`) VALUES
(2, 1, 2, 10, 50, 0, 500, '2020-10-24 09:58:12', '2020-10-24 04:28:12');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `personal_access_tokens`
--

INSERT INTO `personal_access_tokens` (`id`, `tokenable_type`, `tokenable_id`, `name`, `token`, `abilities`, `last_used_at`, `created_at`, `updated_at`) VALUES
(37, 'App\\Models\\User', 3, 'mobile', '1a1b1a19957b26279bb1c01d8f023f6d713e266ade74b3c18da3df42bbc49d63', '[\"*\"]', NULL, '2020-10-11 00:35:21', '2020-10-11 00:35:21'),
(38, 'App\\Models\\User', 1, 'mobile', '8aebfecc3d647c8a30f7af191b101dd1ed8717c67c4082eebbe66349e465d0aa', '[\"*\"]', '2020-10-11 01:46:27', '2020-10-11 01:12:02', '2020-10-11 01:46:27'),
(42, 'App\\Models\\User', 4, 'mobile', '5ab47f6b098ff5fc62a658bdc3fee3214aa61b1f16962a06904cc08aadc47498', '[\"*\"]', '2020-10-11 05:07:15', '2020-10-11 05:06:25', '2020-10-11 05:07:15'),
(43, 'App\\Models\\User', 5, 'mobile', '5df24cc2b4608005703049e1657ae1f82c5a446a4d6074b3a6d69b92987265dd', '[\"*\"]', '2020-10-11 05:15:29', '2020-10-11 05:07:53', '2020-10-11 05:15:29'),
(44, 'App\\Models\\User', 5, 'mobile', 'bad9fc64d6d12dd0b9701e482cc03d9c4c1fc9f8315b4dd9a533f0383dc3dcff', '[\"*\"]', NULL, '2020-10-11 07:17:56', '2020-10-11 07:17:56'),
(45, 'App\\Models\\User', 1, 'mobile', '46f6593fa98b5d67a1f766d0cf296edf1e7ddf53bbd4e8d5693c0da3dbd9ea9d', '[\"*\"]', '2020-10-11 10:52:16', '2020-10-11 07:18:07', '2020-10-11 10:52:16'),
(46, 'App\\Models\\User', 1, 'mobile', '74292b5b0930553e69dff4d589431167b3dfb5cb8ca3d51a2be31de5c28b19bc', '[\"*\"]', NULL, '2020-10-11 07:33:51', '2020-10-11 07:33:51'),
(47, 'App\\Models\\User', 21, 'mobile', '645e17a1e53341f3a08f1e42055895b41f4de626857e52ec764abf311a0c8514', '[\"*\"]', '2020-10-11 10:54:32', '2020-10-11 10:52:29', '2020-10-11 10:54:32'),
(48, 'App\\Models\\User', 1, 'mobile', '0cdb29a439fd2798a880ac9cb89c73f566aee32b43b07e4b07f81df3d7cb5ccd', '[\"*\"]', '2020-10-12 17:34:22', '2020-10-11 10:54:40', '2020-10-12 17:34:22'),
(49, 'App\\Models\\User', 5, 'mobile', 'c58f5eb5817968a031321ca44ee151b0243c976f83d517070ae8c0c855c2d47b', '[\"*\"]', NULL, '2020-10-11 10:55:43', '2020-10-11 10:55:43'),
(50, 'App\\Models\\User', 21, 'mobile', 'cf1bf62acbdd28d08c1981b1220c7a43a51ed2a618d9d17456dafcdbc5d87fde', '[\"*\"]', NULL, '2020-10-11 10:56:05', '2020-10-11 10:56:05'),
(51, 'App\\Models\\User', 21, 'mobile', 'e436a425cf7b87753ef6353b039f32b384305d1f2a73dc54c6f7ca536349d1fc', '[\"*\"]', '2020-10-13 17:31:15', '2020-10-12 17:36:17', '2020-10-13 17:31:15'),
(52, 'App\\Models\\User', 5, 'mobile', '4fce8d459c4904a7e66d6d134a39eba4a7b8bae1926720374b0a809d1ab308ba', '[\"*\"]', '2020-10-18 00:46:42', '2020-10-13 17:32:06', '2020-10-18 00:46:42'),
(54, 'App\\Models\\User', 24, 'mobile', '5da5d035ba37c8b654e6fbed3acadba826d2b5b081bb677ccfa5efca0a916473', '[\"*\"]', NULL, '2020-10-13 17:46:22', '2020-10-13 17:46:22'),
(55, 'App\\Models\\User', 24, 'mobile', '71e676cee4086464b8cf78012313547190e1ea198430b12f2e0c4b5f50087f35', '[\"*\"]', NULL, '2020-10-13 17:46:26', '2020-10-13 17:46:26'),
(56, 'App\\Models\\User', 5, 'mobile', '743ebcc942db10d6c486816aa1b3ee2da86be4508ecf9abd1228b68941b075a6', '[\"*\"]', '2020-10-18 00:49:11', '2020-10-18 00:48:46', '2020-10-18 00:49:11'),
(57, 'App\\Models\\User', 5, 'mobile', '24f746b7af2b25434c9870806e447900fef13da79c3c4db1ac807cb1b97e5f7c', '[\"*\"]', '2020-10-18 01:11:59', '2020-10-18 00:49:58', '2020-10-18 01:11:59'),
(58, 'App\\Models\\User', 5, 'mobile', '021fd3f64af466dede121820048b0a92bb3e33a682f00c6eabede4b488b68441', '[\"*\"]', NULL, '2020-10-18 01:15:34', '2020-10-18 01:15:34'),
(59, 'App\\Models\\User', 5, 'mobile', '8d3f801f9b506e248f2eea9474aa8d176223667f276d0bc245061a1780363499', '[\"*\"]', '2020-10-18 04:39:44', '2020-10-18 01:19:26', '2020-10-18 04:39:44'),
(60, 'App\\Models\\User', 5, 'mobile', 'd4b8c1ee08ec568e0ecffd1db20c4226682e669e806c3c9e3bb55d37e4b556be', '[\"*\"]', NULL, '2020-10-18 04:45:53', '2020-10-18 04:45:53'),
(61, 'App\\Models\\User', 5, 'mobile', '9deb03652e3046e4baefec72c236361edb0b4b5284e4680625b3cb9b415adb54', '[\"*\"]', NULL, '2020-10-18 04:46:51', '2020-10-18 04:46:51'),
(62, 'App\\Models\\User', 5, 'mobile', '7b89418f18eb6be70c3f66be1b5c032ad73292688d185193015fb65af40056ae', '[\"*\"]', '2020-10-18 04:50:59', '2020-10-18 04:50:43', '2020-10-18 04:50:59'),
(63, 'App\\Models\\User', 5, 'mobile', 'dc88a875454e56880d885c18e3fbca034071a0e77c363c347260ab5a91b9e416', '[\"*\"]', NULL, '2020-10-18 08:12:51', '2020-10-18 08:12:51'),
(64, 'App\\Models\\User', 5, 'mobile', 'eeecd2532bc4caa993c0aaf316791fb643e29e3f290c84792efbc26606c29e3c', '[\"*\"]', NULL, '2020-10-18 08:13:06', '2020-10-18 08:13:06'),
(65, 'App\\Models\\User', 5, 'mobile', 'e3ac619e2cb9795a604d39ad60899cd35a0fb27341166d16b059ac8306f8bef8', '[\"*\"]', NULL, '2020-10-23 19:15:52', '2020-10-23 19:15:52'),
(66, 'App\\Models\\User', 5, 'mobile', 'f9f9d249cb90e3250a8b1d611a2b462c1dada7d8031877a16455ab63ecca7a71', '[\"*\"]', NULL, '2020-10-24 08:32:10', '2020-10-24 08:32:10');

-- --------------------------------------------------------

--
-- Table structure for table `pr_category`
--

CREATE TABLE `pr_category` (
  `id` bigint(20) NOT NULL COMMENT 'primary key',
  `super_cat_id` bigint(20) DEFAULT NULL COMMENT 'Super category id FK to PK of same table',
  `category_name` varchar(50) NOT NULL COMMENT 'Category name',
  `created_at` datetime NOT NULL COMMENT 'Record created date',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Record modified datetime'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pr_category`
--

INSERT INTO `pr_category` (`id`, `super_cat_id`, `category_name`, `created_at`, `updated_at`) VALUES
(1, 3, 'sqaure line', '2020-10-18 11:41:37', '2020-10-18 08:39:48'),
(2, NULL, 'stationary', '2020-10-18 11:41:37', '2020-10-18 06:13:59'),
(3, 2, 'books', '2020-10-18 11:44:25', '2020-10-18 06:14:20'),
(4, 3, 'CR books', '2020-10-18 11:44:25', '2020-10-18 06:14:20'),
(5, 3, 'normal line', '2020-10-18 13:43:57', '2020-10-18 08:13:57'),
(10, NULL, 'Apparel', '2020-10-24 23:37:18', '2020-10-24 18:07:30'),
(11, NULL, 'Vehicle', '2020-10-24 23:37:34', '2020-10-24 18:07:55'),
(12, NULL, 'Entertainment', '2020-10-24 23:38:23', '2020-10-24 18:08:35');

-- --------------------------------------------------------

--
-- Table structure for table `pr_product`
--

CREATE TABLE `pr_product` (
  `id` bigint(20) NOT NULL COMMENT 'AUTO_INCREMENT',
  `category_id` bigint(20) NOT NULL COMMENT 'product category id FK to product category table',
  `owner_id` bigint(20) NOT NULL COMMENT 'product owner id fk to user table',
  `product_name` varchar(300) NOT NULL COMMENT 'Product name',
  `short_desc` text NOT NULL COMMENT 'A Short description about the product',
  `long_desc` text NOT NULL COMMENT 'A Long description about the product',
  `created_at` datetime NOT NULL COMMENT 'Record Created at',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT 'Record Updated at'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pr_product`
--

INSERT INTO `pr_product` (`id`, `category_id`, `owner_id`, `product_name`, `short_desc`, `long_desc`, `created_at`, `updated_at`) VALUES
(1, 3, 5, 'normal line', 'test update short_desc', 'test update long_desc', '2020-10-18 10:32:58', '2020-10-18 05:23:21'),
(2, 10, 1, 'T shirt size 10', 'this is test short dec', 'watch it', '2020-10-23 23:38:53', '2020-10-24 18:10:31'),
(3, 12, 1, 'BT speaker 100W', 'BT speaker brief info', '', '2020-10-20 23:44:04', '2020-10-24 18:15:34'),
(4, 11, 1, 'Scooter ride', 'short discription for scooter', '', '2020-10-27 23:46:00', '2020-10-24 18:17:27');

-- --------------------------------------------------------

--
-- Table structure for table `pr_product_info`
--

CREATE TABLE `pr_product_info` (
  `id` bigint(20) NOT NULL,
  `product_id` bigint(20) NOT NULL COMMENT 'fk to pr_product table',
  `price` double NOT NULL COMMENT 'Product price',
  `quatity` double NOT NULL COMMENT 'Product available quantity',
  `default_image` text DEFAULT NULL COMMENT 'image base64',
  `product_images` text DEFAULT NULL COMMENT 'other images token not default image - future dev',
  `created_at` datetime NOT NULL COMMENT 'Record Created at',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT 'Record Updated at'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pr_product_info`
--

INSERT INTO `pr_product_info` (`id`, `product_id`, `price`, `quatity`, `default_image`, `product_images`, `created_at`, `updated_at`) VALUES
(1, 1, 150, 40, 'test update short_desc', 'test long_desc update', '2020-10-18 11:43:36', '2020-10-18 11:19:26'),
(2, 2, 899, 17, 'image base 64', 'image base 64', '2020-10-22 23:41:12', '2020-10-24 18:13:13'),
(4, 4, 1299, 1299, 'image basr 64', NULL, '2020-10-26 23:47:42', '2020-10-24 18:18:47'),
(5, 3, 950, 17, 'image base 64', 'image base 64', '2020-10-22 23:41:12', '2020-10-24 18:21:02');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) NOT NULL,
  `role_name` varchar(50) NOT NULL COMMENT 'name of the user role',
  `created_at` datetime NOT NULL COMMENT 'record created date',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT 'record updated date and time'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `role_name`, `created_at`, `updated_at`) VALUES
(1, 'admin', '0000-00-00 00:00:00', '2020-10-07 15:10:41'),
(2, 'admin_assist', '0000-00-00 00:00:00', '2020-10-07 15:10:19'),
(3, 'seller', '0000-00-00 00:00:00', '2020-10-07 15:10:19'),
(4, 'buyer', '0000-00-00 00:00:00', '2020-10-07 15:10:19');

-- --------------------------------------------------------

--
-- Table structure for table `seller_details`
--

CREATE TABLE `seller_details` (
  `id` bigint(20) UNSIGNED NOT NULL COMMENT 'Auto Increment number',
  `user_id` bigint(20) NOT NULL COMMENT 'user_id FK to users Table',
  `verify_status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '1- verified , 0 - not verified',
  `document` varchar(255) NOT NULL COMMENT 'base64 document',
  `created_at` datetime NOT NULL COMMENT 'record created date time',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT 'record updated date time'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `seller_details`
--

INSERT INTO `seller_details` (`id`, `user_id`, `verify_status`, `document`, `created_at`, `updated_at`) VALUES
(1, 5, 0, 'SADVASVAV', '2020-10-11 10:45:29', '2020-10-13 00:10:02');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) NOT NULL,
  `role_id` bigint(20) NOT NULL COMMENT 'foreign key to role id',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `role_id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 3, 'nuwan ishara123', 'abce@gmail.com', NULL, '$2y$10$Xeu2i6iJdOK8NEyWI9cQz.HI4n9b5o8GaJQ0TfisWOkJqWaReeUW6', NULL, '2020-10-12 17:12:18', '2020-10-12 17:12:18'),
(5, 1, 'nuwan ishara', 'abca@gmail.com', NULL, '$2y$10$R1DZ4rgli.FYxgQRtXryn.ThqoyLBzPBnFT8jjhnylWwIX22wZT32', NULL, '2020-10-11 05:07:53', '2020-10-11 05:07:53'),
(21, 1, 'nuwan ishara', 'abcd@gmail.com', NULL, '$2y$10$QNaqKxDbXEOf4Zr8pjTgLOjUt4dT4pyNYB0hHdxm133/6LYfHiGdy', NULL, '2020-10-11 07:40:00', '2020-10-11 07:40:00'),
(22, 4, 'nuwan ishara', 'seller@gmail.com', NULL, '$2y$10$vMl0mEiVlEO8unS3U3Z4kOFMBi/43J5jtwxa1a9VXsrLa.9hbfZna', NULL, '2020-10-11 10:55:03', '2020-10-11 10:55:03'),
(24, 4, 'nuwan ishara', 'buyer@gmail.com', NULL, '$2y$10$FLEHw7/iIsYvTQDP7Yw7WuLyTQiEWhcT2XH1jeIX/JpocimGNDIx2', NULL, '2020-10-13 17:46:22', '2020-10-13 17:46:22');

-- --------------------------------------------------------

--
-- Table structure for table `user_activities`
--

CREATE TABLE `user_activities` (
  `id` bigint(20) NOT NULL COMMENT 'Log ID (Auto Increment)',
  `uidx` bigint(20) DEFAULT NULL COMMENT 'User Index ID',
  `user_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `activity` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Funcation user did',
  `url` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Current URL',
  `controller_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'user access controller FK to controller table',
  `action_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'user perform action FK to action table',
  `parameters` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'URL Parameters',
  `status` int(11) NOT NULL COMMENT 'success-1,fail - 0',
  `ip_addr` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'IP Address ',
  `date_time` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Date and time of the activity',
  `time_diff` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'difference of login and logout',
  `imi` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'mobile imi number',
  `dev_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'mobile device name',
  `ua_browser` text COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'User''s Web Browser',
  `latitude` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'mobile gps location latitude',
  `longitude` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'mobile gps location longitude',
  `modified_at` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'updated at'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_activities`
--

INSERT INTO `user_activities` (`id`, `uidx`, `user_name`, `activity`, `url`, `controller_name`, `action_name`, `parameters`, `status`, `ip_addr`, `date_time`, `time_diff`, `imi`, `dev_name`, `ua_browser`, `latitude`, `longitude`, `modified_at`) VALUES
(1, 1, NULL, 'INVALID_DATA_TYPE', 'http://127.0.0.1:8000/api/roles/byname/admin', 'App\\Http\\Controllers\\Auth\\RolesController', 'getByName', 'http://127.0.0.1:8000/api/roles/byname/admin', 0, '127.0.0.1', '2020-10-11 01:46:07', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 07:16:07'),
(2, 1, NULL, 'INVALID_DATA_TYPE', 'http://127.0.0.1:8000/api/roles/byname/admin', 'App\\Http\\Controllers\\Auth\\RolesController', 'getByName', 'http://127.0.0.1:8000/api/roles/byname/admin', 0, '127.0.0.1', '2020-10-11 01:46:07', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 07:16:07'),
(3, 1, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/roles/byname/admin', 'App\\Http\\Controllers\\Auth\\RolesController', 'getByName', 'http://127.0.0.1:8000/api/roles/byname/admin', 1, '127.0.0.1', '2020-10-11 01:46:27', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 07:16:27'),
(4, NULL, NULL, 'view data of the given role buyer', 'http://127.0.0.1:8000/api/register/seller', 'App\\Http\\Controllers\\Auth\\AuthController', 'registerSeller', 'http://127.0.0.1:8000/api/register/seller', 1, '127.0.0.1', '2020-10-11 01:50:58', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 07:20:58'),
(5, NULL, NULL, 'view data of the given role buyer', 'http://127.0.0.1:8000/api/register/seller', 'App\\Http\\Controllers\\Auth\\AuthController', 'registerSeller', 'http://127.0.0.1:8000/api/register/seller', 1, '127.0.0.1', '2020-10-11 01:52:18', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 07:22:18'),
(6, NULL, NULL, 'view data of the given role buyer', 'http://127.0.0.1:8000/api/register/seller', 'App\\Http\\Controllers\\Auth\\AuthController', 'registerSeller', 'http://127.0.0.1:8000/api/register/seller', 1, '127.0.0.1', '2020-10-11 01:52:34', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 07:22:34'),
(7, NULL, NULL, 'view data of the given role buyer', 'http://127.0.0.1:8000/api/register/seller', 'App\\Http\\Controllers\\Auth\\AuthController', 'registerSeller', 'http://127.0.0.1:8000/api/register/seller', 1, '127.0.0.1', '2020-10-11 01:53:08', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 07:23:08'),
(8, NULL, NULL, 'view data of the given role buyer', 'http://127.0.0.1:8000/api/register/seller', 'App\\Http\\Controllers\\Auth\\AuthController', 'registerSeller', 'http://127.0.0.1:8000/api/register/seller', 1, '127.0.0.1', '2020-10-11 01:54:00', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 07:24:00'),
(10, 4, NULL, 'USER_NOT_A_SELLER', 'http://127.0.0.1:8000/api/register/verify', 'App\\Http\\Controllers\\Auth\\AuthController', 'verifySeller', 'http://127.0.0.1:8000/api/register/verify', 0, '127.0.0.1', '2020-10-11 05:06:41', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 10:36:41'),
(12, NULL, NULL, 'view data of the given role seller', 'http://127.0.0.1:8000/api/register/seller', 'App\\Http\\Controllers\\Auth\\AuthController', 'registerSeller', 'http://127.0.0.1:8000/api/register/seller', 1, '127.0.0.1', '2020-10-11 05:07:53', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 10:37:53'),
(15, 5, NULL, 'SQLSTATE[HY000]: General error: 1364 Field \'verify_status\' doesn\'t have a default value (SQL: insert into `seller_details` (`user_id`, `document`, `created_at`, `updated_at`) values (5, nuwan ishara, 2020-10-11 10:42:50, 2020-10-11 10:42:50))', 'http://127.0.0.1:8000/api/register/verify', 'App\\Http\\Controllers\\Auth\\AuthController', 'verifySeller', 'http://127.0.0.1:8000/api/register/verify', 0, '127.0.0.1', '2020-10-11 05:12:50', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 10:42:50'),
(18, 5, NULL, 'view data of the given role seller', 'http://127.0.0.1:8000/api/register/verify', 'App\\Http\\Controllers\\Auth\\AuthController', 'verifySeller', 'http://127.0.0.1:8000/api/register/verify', 1, '127.0.0.1', '2020-10-11 05:15:29', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 10:45:29'),
(19, 5, NULL, 'serller verification step 2 completed: 5', 'http://127.0.0.1:8000/api/register/verify', 'App\\Http\\Controllers\\Auth\\AuthController', 'verifySeller', 'http://127.0.0.1:8000/api/register/verify', 1, '127.0.0.1', '2020-10-11 05:15:29', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 10:45:29'),
(20, 1, NULL, 'User created: nuwan ishara', 'http://127.0.0.1:8000/api/usermgt/create', 'App\\Http\\Controllers\\Admin\\AdminController', 'adminAssistCreate', 'http://127.0.0.1:8000/api/usermgt/create', 1, '127.0.0.1', '2020-10-11 07:25:03', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 12:55:03'),
(24, 1, NULL, 'User created: nuwan ishara', 'http://127.0.0.1:8000/api/usermgt/create', 'App\\Http\\Controllers\\Admin\\AdminController', 'adminAssistCreate', 'http://127.0.0.1:8000/api/usermgt/create', 1, '127.0.0.1', '2020-10-11 07:27:43', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 12:57:43'),
(43, 1, NULL, 'User created: nuwan ishara', 'http://127.0.0.1:8000/api/usermgt/create', 'App\\Http\\Controllers\\Admin\\AdminController', 'adminAssistCreate', 'http://127.0.0.1:8000/api/usermgt/create', 1, '127.0.0.1', '2020-10-11 07:40:00', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 13:10:00'),
(44, 1, NULL, 'view data of the given role 2', 'http://127.0.0.1:8000/api/usermgt/create', 'App\\Http\\Controllers\\Admin\\AdminController', 'adminAssistCreate', 'http://127.0.0.1:8000/api/usermgt/create', 1, '127.0.0.1', '2020-10-11 07:40:00', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 13:10:00'),
(45, 1, NULL, 'Trying to get property \'role_id\' of non-object', 'http://127.0.0.1:8000/api/usermgt/create', 'App\\Http\\Controllers\\Admin\\AdminController', 'adminAssistCreate', 'http://127.0.0.1:8000/api/usermgt/create', 0, '127.0.0.1', '2020-10-11 07:44:36', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 13:14:36'),
(65, 1, NULL, 'ACCESS_DENIED', 'http://127.0.0.1:8000/api/usermgt/create', 'App\\Http\\Controllers\\Admin\\AdminController', 'adminAssistCreate', 'http://127.0.0.1:8000/api/usermgt/create', 0, '127.0.0.1', '2020-10-11 10:51:10', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:21:10'),
(66, 1, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:51:50', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:21:50'),
(67, 1, NULL, 'view data of the given role admin_assist', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:51:50', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:21:50'),
(68, 1, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:51:50', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:21:50'),
(69, 1, NULL, 'view data of the given role admin_assist', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:51:50', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:21:50'),
(70, 1, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:51:50', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:21:50'),
(71, 1, NULL, 'view all data users', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:51:50', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:21:50'),
(72, 1, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:52:16', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:22:16'),
(73, 1, NULL, 'view data of the given role admin_assist', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:52:16', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:22:16'),
(74, 1, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:52:16', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:22:16'),
(75, 1, NULL, 'view data of the given role admin_assist', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:52:16', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:22:16'),
(76, 1, NULL, 'view all data users', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:52:16', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:22:16'),
(77, 21, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:52:43', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:22:43'),
(78, 21, NULL, 'view data of the given role admin_assist', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:52:43', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:22:43'),
(79, 21, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:52:43', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:22:43'),
(80, 21, NULL, 'view data of the given role admin_assist', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:52:43', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:22:43'),
(81, 21, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:52:43', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:22:43'),
(82, 21, NULL, 'view all data users', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:52:43', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:22:43'),
(83, 21, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:54:06', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:24:06'),
(84, 21, NULL, 'view data of the given role admin_assist', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:54:06', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:24:06'),
(85, 21, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:54:06', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:24:06'),
(86, 21, NULL, 'view data of the given role admin_assist', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:54:06', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:24:06'),
(87, 21, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:54:06', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:24:06'),
(88, 21, NULL, 'view all data users', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-11 10:54:06', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:24:06'),
(90, 21, NULL, 'ACCESS_DENIED', 'http://127.0.0.1:8000/api/usermgt/create', 'App\\Http\\Controllers\\Admin\\AdminController', 'adminAssistCreate', 'http://127.0.0.1:8000/api/usermgt/create', 0, '127.0.0.1', '2020-10-11 10:54:32', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:24:32'),
(92, 1, NULL, 'EMAIL_ALREADY_IN_USE', 'http://127.0.0.1:8000/api/usermgt/create', 'App\\Http\\Controllers\\Admin\\AdminController', 'adminAssistCreate', 'http://127.0.0.1:8000/api/usermgt/create', 0, '127.0.0.1', '2020-10-11 10:54:54', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:24:54'),
(93, 1, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/create', 'App\\Http\\Controllers\\Admin\\AdminController', 'adminAssistCreate', 'http://127.0.0.1:8000/api/usermgt/create', 1, '127.0.0.1', '2020-10-11 10:55:03', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:25:03'),
(94, 1, NULL, 'User created: nuwan ishara', 'http://127.0.0.1:8000/api/usermgt/create', 'App\\Http\\Controllers\\Admin\\AdminController', 'adminAssistCreate', 'http://127.0.0.1:8000/api/usermgt/create', 1, '127.0.0.1', '2020-10-11 10:55:03', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:25:03'),
(95, 1, NULL, 'view data of the given role 4', 'http://127.0.0.1:8000/api/usermgt/create', 'App\\Http\\Controllers\\Admin\\AdminController', 'adminAssistCreate', 'http://127.0.0.1:8000/api/usermgt/create', 1, '127.0.0.1', '2020-10-11 10:55:03', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:25:03'),
(97, 1, NULL, 'EMAIL_ALREADY_IN_USE', 'http://127.0.0.1:8000/api/usermgt/create', 'App\\Http\\Controllers\\Admin\\AdminController', 'adminAssistCreate', 'http://127.0.0.1:8000/api/usermgt/create', 0, '127.0.0.1', '2020-10-11 10:58:41', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:28:41'),
(98, 1, NULL, 'view data of the given role 22', 'http://127.0.0.1:8000/api/usermgt/users/byid/22', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUserById', 'http://127.0.0.1:8000/api/usermgt/users/byid/22', 1, '127.0.0.1', '2020-10-11 11:03:06', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-11 16:33:06'),
(99, 1, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-12 09:51:27', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 15:21:27'),
(100, 1, NULL, 'view data of the given role admin_assist', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-12 09:51:27', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 15:21:27'),
(101, 1, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-12 09:51:27', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 15:21:27'),
(102, 1, NULL, 'view data of the given role admin_assist', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-12 09:51:28', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 15:21:28'),
(103, 1, NULL, 'view all data users', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-12 09:51:28', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 15:21:28'),
(104, 1, NULL, 'view data of the given role 22', 'http://127.0.0.1:8000/api/usermgt/users/byid/22', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUserById', 'http://127.0.0.1:8000/api/usermgt/users/byid/22', 1, '127.0.0.1', '2020-10-12 09:51:36', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 15:21:36'),
(105, 1, NULL, 'User update name: nuwan ishara123', 'http://127.0.0.1:8000/api/usermgt/update/22', 'App\\Http\\Controllers\\Admin\\AdminController', 'adminAssistUpdate', 'http://127.0.0.1:8000/api/usermgt/update/22', 1, '127.0.0.1', '2020-10-12 17:12:05', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 22:42:05'),
(106, 1, NULL, 'view data of the given role 4', 'http://127.0.0.1:8000/api/usermgt/update/22', 'App\\Http\\Controllers\\Admin\\AdminController', 'adminAssistUpdate', 'http://127.0.0.1:8000/api/usermgt/update/22', 1, '127.0.0.1', '2020-10-12 17:12:05', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 22:42:05'),
(107, 1, NULL, 'User update name: nuwan ishara123', 'http://127.0.0.1:8000/api/usermgt/update/22', 'App\\Http\\Controllers\\Admin\\AdminController', 'adminAssistUpdate', 'http://127.0.0.1:8000/api/usermgt/update/22', 1, '127.0.0.1', '2020-10-12 17:12:18', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 22:42:18'),
(108, 1, NULL, 'view data of the given role 3', 'http://127.0.0.1:8000/api/usermgt/update/22', 'App\\Http\\Controllers\\Admin\\AdminController', 'adminAssistUpdate', 'http://127.0.0.1:8000/api/usermgt/update/22', 1, '127.0.0.1', '2020-10-12 17:12:18', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 22:42:18'),
(114, 21, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/verify/1', 'App\\Http\\Controllers\\Admin\\AdminController', 'verifySellerByAdmin', 'http://127.0.0.1:8000/api/usermgt/verify/1', 1, '127.0.0.1', '2020-10-12 17:37:11', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 23:07:11'),
(115, 21, NULL, 'view data of the given role admin_assist', 'http://127.0.0.1:8000/api/usermgt/verify/1', 'App\\Http\\Controllers\\Admin\\AdminController', 'verifySellerByAdmin', 'http://127.0.0.1:8000/api/usermgt/verify/1', 1, '127.0.0.1', '2020-10-12 17:37:11', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 23:07:11'),
(116, 21, NULL, 'admin verification step 2 completed: 21', 'http://127.0.0.1:8000/api/usermgt/verify/1', 'App\\Http\\Controllers\\Admin\\AdminController', 'verifySellerByAdmin', 'http://127.0.0.1:8000/api/usermgt/verify/1', 1, '127.0.0.1', '2020-10-12 17:37:11', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 23:07:11'),
(121, 21, NULL, 'The given data was invalid.', 'http://127.0.0.1:8000/api/usermgt/verify/1', 'App\\Http\\Controllers\\Admin\\AdminController', 'verifySellerByAdmin', 'http://127.0.0.1:8000/api/usermgt/verify/1', 0, '127.0.0.1', '2020-10-12 17:38:17', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 23:08:17'),
(144, 21, NULL, 'The given data was invalid.', 'http://127.0.0.1:8000/api/usermgt/verify/1', 'App\\Http\\Controllers\\Admin\\AdminController', 'verifySellerByAdmin', 'http://127.0.0.1:8000/api/usermgt/verify/1', 0, '127.0.0.1', '2020-10-12 18:07:24', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 23:37:24'),
(149, 21, NULL, 'The given data was invalid.', 'http://127.0.0.1:8000/api/usermgt/verify/1', 'App\\Http\\Controllers\\Admin\\AdminController', 'verifySellerByAdmin', 'http://127.0.0.1:8000/api/usermgt/verify/1', 0, '127.0.0.1', '2020-10-12 18:13:08', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 23:43:08'),
(152, 21, NULL, 'ACCESS_DENIED', 'http://127.0.0.1:8000/api/usermgt/verify/1', 'App\\Http\\Controllers\\Admin\\AdminController', 'verifySellerByAdmin', 'http://127.0.0.1:8000/api/usermgt/verify/1', 0, '127.0.0.1', '2020-10-12 18:13:30', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 23:43:30'),
(159, 21, NULL, 'ACCESS_DENIED', 'http://127.0.0.1:8000/api/usermgt/verify/1', 'App\\Http\\Controllers\\Admin\\AdminController', 'verifySellerByAdmin', 'http://127.0.0.1:8000/api/usermgt/verify/1', 0, '127.0.0.1', '2020-10-12 18:19:48', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 23:49:48'),
(162, 21, NULL, 'ACCESS_DENIED', 'http://127.0.0.1:8000/api/usermgt/verify/1', 'App\\Http\\Controllers\\Admin\\AdminController', 'verifySellerByAdmin', 'http://127.0.0.1:8000/api/usermgt/verify/1', 0, '127.0.0.1', '2020-10-12 18:20:09', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 23:50:09'),
(165, 21, NULL, 'ACCESS_DENIED', 'http://127.0.0.1:8000/api/usermgt/verify/1', 'App\\Http\\Controllers\\Admin\\AdminController', 'verifySellerByAdmin', 'http://127.0.0.1:8000/api/usermgt/verify/1', 0, '127.0.0.1', '2020-10-12 18:20:27', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 23:50:27'),
(168, 21, NULL, 'ACCESS_DENIED', 'http://127.0.0.1:8000/api/usermgt/verify/1', 'App\\Http\\Controllers\\Admin\\AdminController', 'verifySellerByAdmin', 'http://127.0.0.1:8000/api/usermgt/verify/1', 0, '127.0.0.1', '2020-10-12 18:21:03', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 23:51:03'),
(171, 21, NULL, 'The given data was invalid.', 'http://127.0.0.1:8000/api/usermgt/verify/1', 'App\\Http\\Controllers\\Admin\\AdminController', 'verifySellerByAdmin', 'http://127.0.0.1:8000/api/usermgt/verify/1', 0, '127.0.0.1', '2020-10-12 18:21:33', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 23:51:33'),
(172, 21, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/verify/1', 'App\\Http\\Controllers\\Admin\\AdminController', 'verifySellerByAdmin', 'http://127.0.0.1:8000/api/usermgt/verify/1', 1, '127.0.0.1', '2020-10-12 18:21:41', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 23:51:41'),
(173, 21, NULL, 'view data of the given role admin_assist', 'http://127.0.0.1:8000/api/usermgt/verify/1', 'App\\Http\\Controllers\\Admin\\AdminController', 'verifySellerByAdmin', 'http://127.0.0.1:8000/api/usermgt/verify/1', 1, '127.0.0.1', '2020-10-12 18:21:41', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 23:51:41'),
(174, 21, NULL, 'admin verification step 2 completed: 21', 'http://127.0.0.1:8000/api/usermgt/verify/1', 'App\\Http\\Controllers\\Admin\\AdminController', 'verifySellerByAdmin', 'http://127.0.0.1:8000/api/usermgt/verify/1', 1, '127.0.0.1', '2020-10-12 18:21:41', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-12 23:51:41'),
(181, 21, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-12 18:43:07', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-13 00:13:07'),
(182, 21, NULL, 'view data of the given role admin_assist', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-12 18:43:07', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-13 00:13:07'),
(183, 21, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-12 18:43:07', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-13 00:13:07'),
(184, 21, NULL, 'view data of the given role admin_assist', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-12 18:43:07', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-13 00:13:07'),
(185, 21, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-12 18:43:07', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-13 00:13:07'),
(186, 21, NULL, 'view all data users', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-12 18:43:07', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-13 00:13:07'),
(187, 21, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-12 18:44:10', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-13 00:14:10'),
(188, 21, NULL, 'view data of the given role admin_assist', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-12 18:44:10', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-13 00:14:10'),
(189, 21, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-12 18:44:10', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-13 00:14:10'),
(190, 21, NULL, 'view data of the given role admin_assist', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-12 18:44:10', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-13 00:14:10'),
(191, 21, NULL, 'view data of the given role admin', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-12 18:44:10', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-13 00:14:10'),
(192, 21, NULL, 'view all data users', 'http://127.0.0.1:8000/api/usermgt/users', 'App\\Http\\Controllers\\Admin\\AdminController', 'getUsers', 'http://127.0.0.1:8000/api/usermgt/users', 1, '127.0.0.1', '2020-10-12 18:44:10', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-13 00:14:10'),
(207, 21, NULL, 'ACCESS_DENIED', 'http://127.0.0.1:8000/api/register/verify', 'App\\Http\\Controllers\\Auth\\AuthController', 'verifySeller', 'http://127.0.0.1:8000/api/register/verify', 0, '127.0.0.1', '2020-10-13 17:31:15', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-13 23:01:15'),
(209, 5, NULL, 'CANNOT_FIND_VERIFICATION_DETAILS', 'http://127.0.0.1:8000/api/register/verify', 'App\\Http\\Controllers\\Auth\\AuthController', 'getVerifySellerStatus', 'http://127.0.0.1:8000/api/register/verify', 0, '127.0.0.1', '2020-10-13 17:32:37', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-13 23:02:37'),
(212, NULL, NULL, 'Trying to get property \'role_id\' of non-object', 'http://127.0.0.1:8000/api/register/buyer', 'App\\Http\\Controllers\\Auth\\AuthController', 'registerBuyer', 'http://127.0.0.1:8000/api/register/buyer', 0, '127.0.0.1', '2020-10-13 17:42:15', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-13 23:12:15'),
(214, NULL, NULL, 'view data of the given role buyer', 'http://127.0.0.1:8000/api/register/buyer', 'App\\Http\\Controllers\\Auth\\AuthController', 'registerBuyer', 'http://127.0.0.1:8000/api/register/buyer', 1, '127.0.0.1', '2020-10-13 17:46:22', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-13 23:16:22'),
(215, NULL, NULL, 'Undefined property: Symfony\\Component\\HttpFoundation\\HeaderBag::$HeaderBag', 'http://127.0.0.1:8000/api/inventory/products', 'App\\Http\\Controllers\\Inventory\\ProductsController', 'create', 'http://127.0.0.1:8000/api/inventory/products', 0, '127.0.0.1', '2020-10-17 21:40:14', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 03:10:14'),
(216, NULL, NULL, 'SQLSTATE[23000]: Integrity constraint violation: 1048 Column \'role_name\' cannot be null (SQL: insert into `roles` (`role_name`, `created_at`, `updated_at`) values (?, 2020-10-18 03:18:29, 2020-10-18 03:18:29))', 'http://127.0.0.1:8000/api/inventory/products', 'App\\Http\\Controllers\\Inventory\\ProductsController', 'create', 'http://127.0.0.1:8000/api/inventory/products', 0, '127.0.0.1', '2020-10-17 21:48:29', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 03:18:29'),
(217, NULL, NULL, 'SQLSTATE[23000]: Integrity constraint violation: 1048 Column \'role_name\' cannot be null (SQL: insert into `roles` (`role_name`, `created_at`, `updated_at`) values (?, 2020-10-18 03:18:59, 2020-10-18 03:18:59))', 'http://127.0.0.1:8000/api/inventory/products', 'App\\Http\\Controllers\\Inventory\\ProductsController', 'create', 'http://127.0.0.1:8000/api/inventory/products', 0, '127.0.0.1', '2020-10-17 21:48:59', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 03:18:59'),
(218, NULL, NULL, 'SQLSTATE[23000]: Integrity constraint violation: 1048 Column \'role_name\' cannot be null (SQL: insert into `roles` (`role_name`, `created_at`, `updated_at`) values (?, 2020-10-18 03:19:33, 2020-10-18 03:19:33))', 'http://127.0.0.1:8000/api/inventory/products', 'App\\Http\\Controllers\\Inventory\\ProductsController', 'create', 'http://127.0.0.1:8000/api/inventory/products', 0, '127.0.0.1', '2020-10-17 21:49:33', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 03:19:33'),
(220, NULL, NULL, 'ACCESS_DENIED', 'http://127.0.0.1:8000/api/inventory/products', 'App\\Http\\Controllers\\Inventory\\ProductsController', 'create', 'http://127.0.0.1:8000/api/inventory/products', 0, '127.0.0.1', '2020-10-17 21:53:02', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 03:23:02'),
(222, NULL, NULL, 'SELLER_ONLY', 'http://127.0.0.1:8000/api/inventory/products', 'App\\Http\\Controllers\\Inventory\\ProductsController', 'create', 'http://127.0.0.1:8000/api/inventory/products', 0, '127.0.0.1', '2020-10-18 00:46:42', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 06:16:42'),
(224, NULL, NULL, 'SELLER_ONLY', 'http://127.0.0.1:8000/api/inventory/products', 'App\\Http\\Controllers\\Inventory\\ProductsController', 'create', 'http://127.0.0.1:8000/api/inventory/products', 0, '127.0.0.1', '2020-10-18 00:49:11', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 06:19:11'),
(226, NULL, NULL, 'SELLER_ONLY', 'http://127.0.0.1:8000/api/inventory/products', 'App\\Http\\Controllers\\Inventory\\ProductsController', 'create', 'http://127.0.0.1:8000/api/inventory/products', 0, '127.0.0.1', '2020-10-18 00:50:27', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 06:20:27'),
(227, NULL, NULL, 'Illegal string offset \'role_id\'', 'http://127.0.0.1:8000/api/inventory/products', 'App\\Http\\Controllers\\Inventory\\ProductsController', 'create', 'http://127.0.0.1:8000/api/inventory/products', 0, '127.0.0.1', '2020-10-18 01:09:44', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 06:39:44'),
(228, NULL, NULL, 'Illegal string offset \'role_id\'', 'http://127.0.0.1:8000/api/inventory/products', 'App\\Http\\Controllers\\Inventory\\ProductsController', 'create', 'http://127.0.0.1:8000/api/inventory/products', 0, '127.0.0.1', '2020-10-18 01:13:58', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 06:43:58'),
(229, NULL, NULL, 'Illegal string offset \'role_id\'', 'http://127.0.0.1:8000/api/inventory/products', 'App\\Http\\Controllers\\Inventory\\ProductsController', 'create', 'http://127.0.0.1:8000/api/inventory/products', 0, '127.0.0.1', '2020-10-18 01:14:52', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 06:44:52'),
(230, NULL, NULL, 'Illegal string offset \'role_id\'', 'http://127.0.0.1:8000/api/inventory/products', 'App\\Http\\Controllers\\Inventory\\ProductsController', 'create', 'http://127.0.0.1:8000/api/inventory/products', 0, '127.0.0.1', '2020-10-18 01:16:33', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 06:46:33'),
(232, NULL, NULL, 'view data of the given role seller', 'http://192.168.8.189:8000/api/inventory/products', 'App\\Http\\Controllers\\Inventory\\ProductsController', 'create', 'http://192.168.8.189:8000/api/inventory/products', 1, '192.168.8.189', '2020-10-18 05:02:58', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 10:32:58'),
(233, NULL, NULL, 'product created role_name: normal line', 'http://192.168.8.189:8000/api/inventory/products', 'App\\Http\\Controllers\\Inventory\\ProductsController', 'create', 'http://192.168.8.189:8000/api/inventory/products', 1, '192.168.8.189', '2020-10-18 05:02:58', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 10:32:58'),
(234, NULL, NULL, 'SQLSTATE[42S22]: Column not found: 1054 Unknown column \'product_name,category_id\' in \'field list\' (SQL: select `id`, `product_name,category_id` from `pr_product` order by `created_at` desc limit 10 offset 0)', 'http://192.168.8.189:8000/api/inventory/products', 'App\\Http\\Controllers\\Inventory\\ProductsController', 'getAllProducts', 'http://192.168.8.189:8000/api/inventory/products', 0, '192.168.8.189', '2020-10-18 05:06:29', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 10:36:29'),
(235, NULL, NULL, 'SQLSTATE[42S22]: Column not found: 1054 Unknown column \'product_name,category_id\' in \'field list\' (SQL: select `id`, `product_name,category_id` from `pr_product` order by `created_at` desc limit 10 offset 0)', 'http://192.168.8.189:8000/api/inventory/products', 'App\\Http\\Controllers\\Inventory\\ProductsController', 'getAllProducts', 'http://192.168.8.189:8000/api/inventory/products', 0, '192.168.8.189', '2020-10-18 05:06:39', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 10:36:39'),
(236, NULL, NULL, 'SQLSTATE[42S22]: Column not found: 1054 Unknown column \'product_name,category_id\' in \'field list\' (SQL: select `id`, `product_name,category_id` from `pr_product` order by `created_at` desc limit 10 offset 0)', 'http://192.168.8.189:8000/api/inventory/products', 'App\\Http\\Controllers\\Inventory\\ProductsController', 'getAllProducts', 'http://192.168.8.189:8000/api/inventory/products', 0, '192.168.8.189', '2020-10-18 05:07:23', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 10:37:23'),
(237, NULL, NULL, 'SQLSTATE[42S22]: Column not found: 1054 Unknown column \'product_name,category_id\' in \'field list\' (SQL: select `id`, `product_name,category_id` from `pr_product` order by `created_at` desc limit 10 offset 0)', 'http://192.168.8.189:8000/api/inventory/products', 'App\\Http\\Controllers\\Inventory\\ProductsController', 'getAllProducts', 'http://192.168.8.189:8000/api/inventory/products', 0, '192.168.8.189', '2020-10-18 05:07:37', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 10:37:37'),
(238, NULL, NULL, 'SQLSTATE[42S22]: Column not found: 1054 Unknown column \'product_name,category_id\' in \'field list\' (SQL: select `id`, `product_name,category_id` from `pr_product` order by `created_at` desc limit 10 offset 0)', 'http://192.168.8.189:8000/api/inventory/products', 'App\\Http\\Controllers\\Inventory\\ProductsController', 'getAllProducts', 'http://192.168.8.189:8000/api/inventory/products', 0, '192.168.8.189', '2020-10-18 05:07:46', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 10:37:46'),
(239, NULL, NULL, 'SQLSTATE[42S22]: Column not found: 1054 Unknown column \'category_id\' in \'field list\' (SQL: select `category_id`, `category_name` from `pr_category` where `pr_category`.`id` in (3))', 'http://192.168.8.189:8000/api/inventory/products', 'App\\Http\\Controllers\\Inventory\\ProductsController', 'getAllProducts', 'http://192.168.8.189:8000/api/inventory/products', 0, '192.168.8.189', '2020-10-18 05:08:38', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 10:38:38'),
(240, NULL, NULL, 'SQLSTATE[42S22]: Column not found: 1054 Unknown column \'category_id\' in \'field list\' (SQL: select `category_id`, `category_name` from `pr_category` where `pr_category`.`id` in (3))', 'http://192.168.8.189:8000/api/inventory/products', 'App\\Http\\Controllers\\Inventory\\ProductsController', 'getAllProducts', 'http://192.168.8.189:8000/api/inventory/products', 0, '192.168.8.189', '2020-10-18 05:09:00', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 10:39:00'),
(241, NULL, NULL, 'view data of the given product 2', 'http://192.168.8.189:8000/api/inventory/products/byid/2', 'App\\Http\\Controllers\\Inventory\\ProductsController', 'getById', 'http://192.168.8.189:8000/api/inventory/products/byid/2', 1, '192.168.8.189', '2020-10-18 05:16:06', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 10:46:06'),
(242, NULL, NULL, 'PRODUCT_NOT_AVAILABLE_BY_ID', 'http://192.168.8.189:8000/api/inventory/products/byid/2', 'App\\Http\\Controllers\\Inventory\\ProductsController', 'getById', 'http://192.168.8.189:8000/api/inventory/products/byid/2', 0, '192.168.8.189', '2020-10-18 05:17:08', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 10:47:08'),
(243, NULL, NULL, 'view data of the given product 1', 'http://192.168.8.189:8000/api/inventory/products/byid/1', 'App\\Http\\Controllers\\Inventory\\ProductsController', 'getById', 'http://192.168.8.189:8000/api/inventory/products/byid/1', 1, '192.168.8.189', '2020-10-18 05:17:13', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 10:47:13'),
(244, NULL, NULL, 'view data of the given role seller', 'http://192.168.8.189:8000/api/inventory/products/1', 'App\\Http\\Controllers\\Inventory\\ProductsController', 'update', 'http://192.168.8.189:8000/api/inventory/products/1', 1, '192.168.8.189', '2020-10-18 05:23:21', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 10:53:21'),
(245, NULL, NULL, 'PRODUCT update product_name: normal line ,short_desc:test update short_desc', 'http://192.168.8.189:8000/api/inventory/products/1', 'App\\Http\\Controllers\\Inventory\\ProductsController', 'update', 'http://192.168.8.189:8000/api/inventory/products/1', 1, '192.168.8.189', '2020-10-18 05:23:21', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 10:53:21'),
(246, NULL, NULL, 'Undefined variable: request', 'http://192.168.8.189:8000/api/inventory/products/1', 'App\\Http\\Controllers\\Inventory\\ProductsController', 'delete', 'http://192.168.8.189:8000/api/inventory/products/1', 0, '192.168.8.189', '2020-10-18 05:26:20', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 10:56:20'),
(249, NULL, NULL, 'view data of the given product book', 'http://192.168.8.189:8000/api/inventory/products/byname/book', 'App\\Http\\Controllers\\Inventory\\ProductsController', 'getByName', 'http://192.168.8.189:8000/api/inventory/products/byname/book', 1, '192.168.8.189', '2020-10-18 05:52:01', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 11:22:01'),
(250, NULL, NULL, 'view data of the given product rule', 'http://192.168.8.189:8000/api/inventory/products/byname/rule', 'App\\Http\\Controllers\\Inventory\\ProductsController', 'getByName', 'http://192.168.8.189:8000/api/inventory/products/byname/rule', 1, '192.168.8.189', '2020-10-18 05:52:10', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 11:22:10'),
(251, NULL, NULL, 'view data of the given product rule', 'http://192.168.8.189:8000/api/inventory/products/byname/rule', 'App\\Http\\Controllers\\Inventory\\ProductsController', 'getByName', 'http://192.168.8.189:8000/api/inventory/products/byname/rule', 1, '192.168.8.189', '2020-10-18 05:52:20', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 11:22:20'),
(252, NULL, NULL, 'view data of the given product rule', 'http://192.168.8.189:8000/api/inventory/products/byname/rule', 'App\\Http\\Controllers\\Inventory\\ProductsController', 'getByName', 'http://192.168.8.189:8000/api/inventory/products/byname/rule', 1, '192.168.8.189', '2020-10-18 05:52:26', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 11:22:26'),
(253, NULL, NULL, 'view data of the given product line', 'http://192.168.8.189:8000/api/inventory/products/byname/line', 'App\\Http\\Controllers\\Inventory\\ProductsController', 'getByName', 'http://192.168.8.189:8000/api/inventory/products/byname/line', 1, '192.168.8.189', '2020-10-18 05:52:48', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 11:22:48'),
(254, NULL, NULL, 'view data of the given product line', 'http://192.168.8.189:8000/api/inventory/products/byname/line', 'App\\Http\\Controllers\\Inventory\\ProductsController', 'getByName', 'http://192.168.8.189:8000/api/inventory/products/byname/line', 1, '192.168.8.189', '2020-10-18 05:52:56', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 11:22:56'),
(255, NULL, NULL, 'view data of the given product line', 'http://192.168.8.189:8000/api/inventory/products/byname/line', 'App\\Http\\Controllers\\Inventory\\ProductsController', 'getByName', 'http://192.168.8.189:8000/api/inventory/products/byname/line', 1, '192.168.8.189', '2020-10-18 05:53:49', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 11:23:49'),
(256, NULL, NULL, 'view data of the given product line', 'http://192.168.8.189:8000/api/inventory/products/byname/line', 'App\\Http\\Controllers\\Inventory\\ProductsController', 'getByName', 'http://192.168.8.189:8000/api/inventory/products/byname/line', 1, '192.168.8.189', '2020-10-18 05:53:55', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 11:23:55'),
(261, NULL, NULL, 'view data of the given role seller', 'http://192.168.8.189:8000/api/inventory/productinfo', 'App\\Http\\Controllers\\Inventory\\ProductInfoController', 'create', 'http://192.168.8.189:8000/api/inventory/productinfo', 1, '192.168.8.189', '2020-10-18 06:13:36', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 11:43:36'),
(262, NULL, NULL, 'product created product info: 1', 'http://192.168.8.189:8000/api/inventory/productinfo', 'App\\Http\\Controllers\\Inventory\\ProductInfoController', 'create', 'http://192.168.8.189:8000/api/inventory/productinfo', 1, '192.168.8.189', '2020-10-18 06:13:36', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 11:43:36'),
(263, NULL, NULL, 'view data of the given product line', 'http://192.168.8.189:8000/api/inventory/products/byname/line', 'App\\Http\\Controllers\\Inventory\\ProductsController', 'getByName', 'http://192.168.8.189:8000/api/inventory/products/byname/line', 1, '192.168.8.189', '2020-10-18 07:25:03', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 12:55:03'),
(264, NULL, NULL, 'view data of the given product 1', 'http://192.168.8.189:8000/api/inventory/products/byid/1', 'App\\Http\\Controllers\\Inventory\\ProductsController', 'getById', 'http://192.168.8.189:8000/api/inventory/products/byid/1', 1, '192.168.8.189', '2020-10-18 07:25:15', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 12:55:15'),
(265, NULL, NULL, 'view data of the given product 1', 'http://192.168.8.189:8000/api/inventory/products/byid/1', 'App\\Http\\Controllers\\Inventory\\ProductsController', 'getById', 'http://192.168.8.189:8000/api/inventory/products/byid/1', 1, '192.168.8.189', '2020-10-18 07:25:46', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 12:55:46'),
(268, NULL, NULL, 'PRODUCT_INFO_ALREADY_AVAILABLE', 'http://192.168.8.189:8000/api/inventory/productinfo', 'App\\Http\\Controllers\\Inventory\\ProductInfoController', 'create', 'http://192.168.8.189:8000/api/inventory/productinfo', 0, '192.168.8.189', '2020-10-18 07:26:36', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 12:56:36'),
(270, NULL, NULL, 'Property [product_id] does not exist on this collection instance.', 'http://192.168.8.189:8000/api/inventory/productinfo/1', 'App\\Http\\Controllers\\Inventory\\ProductInfoController', 'update', 'http://192.168.8.189:8000/api/inventory/productinfo/1', 0, '192.168.8.189', '2020-10-18 07:35:43', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 13:05:43'),
(273, NULL, NULL, 'Property [product_id] does not exist on this collection instance.', 'http://192.168.8.189:8000/api/inventory/productinfo/1', 'App\\Http\\Controllers\\Inventory\\ProductInfoController', 'update', 'http://192.168.8.189:8000/api/inventory/productinfo/1', 0, '192.168.8.189', '2020-10-18 07:38:16', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 13:08:16'),
(275, NULL, NULL, 'Property [product_id] does not exist on this collection instance.', 'http://192.168.8.189:8000/api/inventory/productinfo/1', 'App\\Http\\Controllers\\Inventory\\ProductInfoController', 'update', 'http://192.168.8.189:8000/api/inventory/productinfo/1', 0, '192.168.8.189', '2020-10-18 07:38:27', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 13:08:27'),
(279, NULL, NULL, 'SQLSTATE[42S22]: Column not found: 1054 Unknown column \'owner_id\' in \'field list\' (SQL: update `pr_product_info` set `default_image` = test update short_desc, `product_images` = test long_desc update, `owner_id` = 5, `pr_product_info`.`updated_at` = 2020-10-18 13:09:25 where `id` = 1)', 'http://192.168.8.189:8000/api/inventory/productinfo/1', 'App\\Http\\Controllers\\Inventory\\ProductInfoController', 'update', 'http://192.168.8.189:8000/api/inventory/productinfo/1', 0, '192.168.8.189', '2020-10-18 07:39:25', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 13:09:25');
INSERT INTO `user_activities` (`id`, `uidx`, `user_name`, `activity`, `url`, `controller_name`, `action_name`, `parameters`, `status`, `ip_addr`, `date_time`, `time_diff`, `imi`, `dev_name`, `ua_browser`, `latitude`, `longitude`, `modified_at`) VALUES
(280, NULL, NULL, 'view data of the given role seller', 'http://192.168.8.189:8000/api/inventory/productinfo/1', 'App\\Http\\Controllers\\Inventory\\ProductInfoController', 'update', 'http://192.168.8.189:8000/api/inventory/productinfo/1', 1, '192.168.8.189', '2020-10-18 07:39:46', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 13:09:46'),
(281, NULL, NULL, 'PRODUCT info update product_id: 1', 'http://192.168.8.189:8000/api/inventory/productinfo/1', 'App\\Http\\Controllers\\Inventory\\ProductInfoController', 'update', 'http://192.168.8.189:8000/api/inventory/productinfo/1', 1, '192.168.8.189', '2020-10-18 07:39:46', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 13:09:46'),
(282, NULL, NULL, 'view data of the given product 1', 'http://192.168.8.189:8000/api/inventory/productinfo/byid/1', 'App\\Http\\Controllers\\Inventory\\ProductInfoController', 'getById', 'http://192.168.8.189:8000/api/inventory/productinfo/byid/1', 1, '192.168.8.189', '2020-10-18 07:50:13', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 13:20:13'),
(285, NULL, NULL, 'ADMINS_ONLY', 'http://192.168.8.189:8000/api/inventory/category', 'App\\Http\\Controllers\\Inventory\\ProductsCategoryController', 'create', 'http://192.168.8.189:8000/api/inventory/category', 0, '192.168.8.189', '2020-10-18 08:06:56', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 13:36:56'),
(288, NULL, NULL, 'ADMINS_ONLY', 'http://192.168.8.189:8000/api/inventory/category', 'App\\Http\\Controllers\\Inventory\\ProductsCategoryController', 'create', 'http://192.168.8.189:8000/api/inventory/category', 0, '192.168.8.189', '2020-10-18 08:07:43', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 13:37:43'),
(291, NULL, NULL, 'ADMINS_ONLY', 'http://192.168.8.189:8000/api/inventory/category', 'App\\Http\\Controllers\\Inventory\\ProductsCategoryController', 'create', 'http://192.168.8.189:8000/api/inventory/category', 0, '192.168.8.189', '2020-10-18 08:09:00', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 13:39:00'),
(294, NULL, NULL, 'ADMINS_ONLY', 'http://192.168.8.189:8000/api/inventory/category', 'App\\Http\\Controllers\\Inventory\\ProductsCategoryController', 'create', 'http://192.168.8.189:8000/api/inventory/category', 0, '192.168.8.189', '2020-10-18 08:09:58', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 13:39:58'),
(295, NULL, NULL, 'view data of the given role admin', 'http://192.168.8.189:8000/api/inventory/category', 'App\\Http\\Controllers\\Inventory\\ProductsCategoryController', 'create', 'http://192.168.8.189:8000/api/inventory/category', 1, '192.168.8.189', '2020-10-18 08:13:57', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 13:43:57'),
(296, NULL, NULL, 'view data of the given role admin_assist', 'http://192.168.8.189:8000/api/inventory/category', 'App\\Http\\Controllers\\Inventory\\ProductsCategoryController', 'create', 'http://192.168.8.189:8000/api/inventory/category', 1, '192.168.8.189', '2020-10-18 08:13:57', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 13:43:57'),
(297, NULL, NULL, 'created category_name: normal line', 'http://192.168.8.189:8000/api/inventory/category', 'App\\Http\\Controllers\\Inventory\\ProductsCategoryController', 'create', 'http://192.168.8.189:8000/api/inventory/category', 1, '192.168.8.189', '2020-10-18 08:13:57', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 13:43:57'),
(298, NULL, NULL, 'SQLSTATE[42S22]: Column not found: 1054 Unknown column \'view_order\' in \'order clause\' (SQL: select `id`, `category_name`, `super_cat_id` from `pr_category` order by `view_order` asc)', 'http://192.168.8.189:8000/api/inventory/category', 'App\\Http\\Controllers\\Inventory\\ProductsCategoryController', 'getAllCategories', 'http://192.168.8.189:8000/api/inventory/category', 0, '192.168.8.189', '2020-10-18 08:22:36', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 13:52:36'),
(299, NULL, NULL, 'view all data racks', 'http://192.168.8.189:8000/api/inventory/category', 'App\\Http\\Controllers\\Inventory\\ProductsCategoryController', 'getAllCategories', 'http://192.168.8.189:8000/api/inventory/category', 1, '192.168.8.189', '2020-10-18 08:22:55', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 13:52:55'),
(300, NULL, NULL, 'view data of the given role admin', 'http://192.168.8.189:8000/api/inventory/category', 'App\\Http\\Controllers\\Inventory\\ProductsCategoryController', 'create', 'http://192.168.8.189:8000/api/inventory/category', 1, '192.168.8.189', '2020-10-18 08:34:04', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 14:04:04'),
(301, NULL, NULL, 'view data of the given role admin_assist', 'http://192.168.8.189:8000/api/inventory/category', 'App\\Http\\Controllers\\Inventory\\ProductsCategoryController', 'create', 'http://192.168.8.189:8000/api/inventory/category', 1, '192.168.8.189', '2020-10-18 08:34:04', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 14:04:04'),
(302, NULL, NULL, 'created category_name: normal line', 'http://192.168.8.189:8000/api/inventory/category', 'App\\Http\\Controllers\\Inventory\\ProductsCategoryController', 'create', 'http://192.168.8.189:8000/api/inventory/category', 1, '192.168.8.189', '2020-10-18 08:34:04', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 14:04:04'),
(305, NULL, NULL, 'PRODUCT_CATEGORY_EXIST', 'http://192.168.8.189:8000/api/inventory/category', 'App\\Http\\Controllers\\Inventory\\ProductsCategoryController', 'create', 'http://192.168.8.189:8000/api/inventory/category', 0, '192.168.8.189', '2020-10-18 08:37:34', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 14:07:34'),
(308, NULL, NULL, 'PRODUCT_CATEGORY_EXIST', 'http://192.168.8.189:8000/api/inventory/category/1', 'App\\Http\\Controllers\\Inventory\\ProductsCategoryController', 'update', 'http://192.168.8.189:8000/api/inventory/category/1', 0, '192.168.8.189', '2020-10-18 08:39:33', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 14:09:33'),
(309, NULL, NULL, 'view data of the given role admin', 'http://192.168.8.189:8000/api/inventory/category/1', 'App\\Http\\Controllers\\Inventory\\ProductsCategoryController', 'update', 'http://192.168.8.189:8000/api/inventory/category/1', 1, '192.168.8.189', '2020-10-18 08:39:48', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 14:09:48'),
(310, NULL, NULL, 'view data of the given role admin_assist', 'http://192.168.8.189:8000/api/inventory/category/1', 'App\\Http\\Controllers\\Inventory\\ProductsCategoryController', 'update', 'http://192.168.8.189:8000/api/inventory/category/1', 1, '192.168.8.189', '2020-10-18 08:39:48', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 14:09:48'),
(311, NULL, NULL, 'update category_name: sqaure line', 'http://192.168.8.189:8000/api/inventory/category/1', 'App\\Http\\Controllers\\Inventory\\ProductsCategoryController', 'update', 'http://192.168.8.189:8000/api/inventory/category/1', 1, '192.168.8.189', '2020-10-18 08:39:48', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 14:09:48'),
(326, NULL, NULL, 'sizeof(): Parameter must be an array or an object that implements Countable', 'http://192.168.8.189:8000/api/inventory/category/1', 'App\\Http\\Controllers\\Inventory\\ProductsCategoryController', 'delete', 'http://192.168.8.189:8000/api/inventory/category/1', 0, '192.168.8.189', '2020-10-18 08:44:03', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 14:14:03'),
(345, NULL, NULL, 'PRODUCT_CATEGORY_CAN_NOT_DELETE_RELATION_DATA_AVAILABLE', 'http://192.168.8.189:8000/api/inventory/category/3', 'App\\Http\\Controllers\\Inventory\\ProductsCategoryController', 'delete', 'http://192.168.8.189:8000/api/inventory/category/3', 0, '192.168.8.189', '2020-10-18 08:47:01', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 14:17:01'),
(346, NULL, NULL, 'view all data racks', 'http://192.168.8.189:8000/api/inventory/category/withproducts/3', 'App\\Http\\Controllers\\Inventory\\ProductsCategoryController', 'getAllWithProducts', 'http://192.168.8.189:8000/api/inventory/category/withproducts/3', 1, '192.168.8.189', '2020-10-18 10:31:44', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 16:01:44'),
(347, NULL, NULL, 'view all data racks', 'http://192.168.8.189:8000/api/inventory/category/nested/3', 'App\\Http\\Controllers\\Inventory\\ProductsCategoryController', 'getAllNestedCategories', 'http://192.168.8.189:8000/api/inventory/category/nested/3', 1, '192.168.8.189', '2020-10-18 10:45:34', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 16:15:34'),
(348, NULL, NULL, 'view all data racks', 'http://192.168.8.189:8000/api/inventory/category', 'App\\Http\\Controllers\\Inventory\\ProductsCategoryController', 'getAllCategories', 'http://192.168.8.189:8000/api/inventory/category', 1, '192.168.8.189', '2020-10-18 10:46:41', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 16:16:41'),
(349, NULL, NULL, 'view data of the given product 1', 'http://192.168.8.189:8000/api/inventory/category', 'App\\Http\\Controllers\\Inventory\\ProductsCategoryController', 'getAllCategories', 'http://192.168.8.189:8000/api/inventory/category', 1, '192.168.8.189', '2020-10-18 10:47:32', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 16:17:32'),
(350, NULL, NULL, 'view data of the given product 1', 'http://192.168.8.189:8000/api/inventory/category', 'App\\Http\\Controllers\\Inventory\\ProductsCategoryController', 'getAllCategories', 'http://192.168.8.189:8000/api/inventory/category', 1, '192.168.8.189', '2020-10-18 10:48:27', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 16:18:27'),
(351, NULL, NULL, 'view all data racks', 'http://192.168.8.189:8000/api/inventory/category/nested/3', 'App\\Http\\Controllers\\Inventory\\ProductsCategoryController', 'getAllNestedCategories', 'http://192.168.8.189:8000/api/inventory/category/nested/3', 1, '192.168.8.189', '2020-10-18 10:48:30', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 16:18:30'),
(352, NULL, NULL, 'Array to string conversion', 'http://192.168.8.189:8000/api/inventory/category', 'App\\Http\\Controllers\\Inventory\\ProductsCategoryController', 'getAllCategories', 'http://192.168.8.189:8000/api/inventory/category', 0, '192.168.8.189', '2020-10-18 10:49:00', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 16:19:00'),
(353, NULL, NULL, 'view data of the given product 1', 'http://192.168.8.189:8000/api/inventory/category', 'App\\Http\\Controllers\\Inventory\\ProductsCategoryController', 'getAllCategories', 'http://192.168.8.189:8000/api/inventory/category', 1, '192.168.8.189', '2020-10-18 10:50:02', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 16:20:02'),
(355, NULL, NULL, 'BUYER_ONLY', 'http://192.168.8.189:8000/api/inventory/productinfo/cart/1', 'App\\Http\\Controllers\\Inventory\\ProductInfoController', 'quantityUpdate', 'http://192.168.8.189:8000/api/inventory/productinfo/cart/1', 0, '192.168.8.189', '2020-10-18 11:18:21', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 16:48:21'),
(356, NULL, NULL, 'view data of the given role buyer', 'http://192.168.8.189:8000/api/inventory/productinfo/cart/1', 'App\\Http\\Controllers\\Inventory\\ProductInfoController', 'quantityUpdate', 'http://192.168.8.189:8000/api/inventory/productinfo/cart/1', 1, '192.168.8.189', '2020-10-18 11:18:43', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 16:48:43'),
(357, NULL, NULL, 'PRODUCT quantity update product_id: 1', 'http://192.168.8.189:8000/api/inventory/productinfo/cart/1', 'App\\Http\\Controllers\\Inventory\\ProductInfoController', 'quantityUpdate', 'http://192.168.8.189:8000/api/inventory/productinfo/cart/1', 1, '192.168.8.189', '2020-10-18 11:18:44', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 16:48:44'),
(359, NULL, NULL, 'PRODUCT_QUANTITY_NOT_AVAILABLE', 'http://192.168.8.189:8000/api/inventory/productinfo/cart/1', 'App\\Http\\Controllers\\Inventory\\ProductInfoController', 'quantityUpdate', 'http://192.168.8.189:8000/api/inventory/productinfo/cart/1', 0, '192.168.8.189', '2020-10-18 11:18:49', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 16:48:49'),
(360, NULL, NULL, 'view data of the given role buyer', 'http://192.168.8.189:8000/api/inventory/productinfo/cart/1', 'App\\Http\\Controllers\\Inventory\\ProductInfoController', 'quantityUpdate', 'http://192.168.8.189:8000/api/inventory/productinfo/cart/1', 1, '192.168.8.189', '2020-10-18 11:19:26', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 16:49:26'),
(361, NULL, NULL, 'PRODUCT quantity update product_id: 1', 'http://192.168.8.189:8000/api/inventory/productinfo/cart/1', 'App\\Http\\Controllers\\Inventory\\ProductInfoController', 'quantityUpdate', 'http://192.168.8.189:8000/api/inventory/productinfo/cart/1', 1, '192.168.8.189', '2020-10-18 11:19:26', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-18 16:49:26'),
(363, NULL, NULL, 'SELLER_ONLY', 'http://192.168.8.189:8000/api/invoice', 'App\\Http\\Controllers\\Invoice\\InvoiceController', 'create', 'http://192.168.8.189:8000/api/invoice', 0, '192.168.8.189', '2020-10-23 21:16:50', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 02:46:50'),
(365, NULL, NULL, 'view data of the given role buyer', 'http://192.168.8.189:8000/api/invoice', 'App\\Http\\Controllers\\Invoice\\InvoiceController', 'create', 'http://192.168.8.189:8000/api/invoice', 1, '192.168.8.189', '2020-10-23 21:23:26', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 02:53:26'),
(366, NULL, NULL, 'invoice created role_name: 24', 'http://192.168.8.189:8000/api/invoice', 'App\\Http\\Controllers\\Invoice\\InvoiceController', 'create', 'http://192.168.8.189:8000/api/invoice', 1, '192.168.8.189', '2020-10-23 21:23:26', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 02:53:26'),
(369, NULL, NULL, 'The given data was invalid.', 'http://192.168.8.189:8000/api/invoice', 'App\\Http\\Controllers\\Invoice\\InvoiceController', 'create', 'http://192.168.8.189:8000/api/invoice', 0, '192.168.8.189', '2020-10-23 21:36:22', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 03:06:22'),
(371, NULL, NULL, 'The given data was invalid.', 'http://192.168.8.189:8000/api/invoice', 'App\\Http\\Controllers\\Invoice\\InvoiceController', 'create', 'http://192.168.8.189:8000/api/invoice', 0, '192.168.8.189', '2020-10-23 21:36:38', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 03:06:38'),
(372, NULL, NULL, 'view data of the given role buyer', 'http://192.168.8.189:8000/api/invoice', 'App\\Http\\Controllers\\Invoice\\InvoiceController', 'create', 'http://192.168.8.189:8000/api/invoice', 1, '192.168.8.189', '2020-10-23 21:36:52', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 03:06:52'),
(373, NULL, NULL, 'invoice created role_name: 24', 'http://192.168.8.189:8000/api/invoice', 'App\\Http\\Controllers\\Invoice\\InvoiceController', 'create', 'http://192.168.8.189:8000/api/invoice', 1, '192.168.8.189', '2020-10-23 21:36:52', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 03:06:52'),
(374, NULL, NULL, 'view data of the given role buyer', 'http://192.168.8.189:8000/api/invoice', 'App\\Http\\Controllers\\Invoice\\InvoiceController', 'getAllInvoices', 'http://192.168.8.189:8000/api/invoice', 1, '192.168.8.189', '2020-10-23 22:42:47', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 04:12:47'),
(375, NULL, NULL, 'view data of the given role buyer', 'http://192.168.8.189:8000/api/invoice', 'App\\Http\\Controllers\\Invoice\\InvoiceController', 'getAllInvoices', 'http://192.168.8.189:8000/api/invoice', 1, '192.168.8.189', '2020-10-23 22:45:37', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 04:15:37'),
(376, NULL, NULL, 'view data of the given role buyer', 'http://192.168.8.189:8000/api/invoice', 'App\\Http\\Controllers\\Invoice\\InvoiceController', 'getAllInvoices', 'http://192.168.8.189:8000/api/invoice', 1, '192.168.8.189', '2020-10-23 22:46:03', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 04:16:03'),
(377, NULL, NULL, 'view data of the given role buyer', 'http://192.168.8.189:8000/api/invoice', 'App\\Http\\Controllers\\Invoice\\InvoiceController', 'getAllInvoices', 'http://192.168.8.189:8000/api/invoice', 1, '192.168.8.189', '2020-10-23 22:46:22', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 04:16:22'),
(378, NULL, NULL, 'view data of the given invoice 1', 'http://192.168.8.189:8000/api/invoice/byid/1', 'App\\Http\\Controllers\\Invoice\\InvoiceController', 'getById', 'http://192.168.8.189:8000/api/invoice/byid/1', 1, '192.168.8.189', '2020-10-23 22:50:31', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 04:20:31'),
(379, NULL, NULL, 'view data of the given invoice 1', 'http://192.168.8.189:8000/api/invoice/byid/1', 'App\\Http\\Controllers\\Invoice\\InvoiceController', 'getById', 'http://192.168.8.189:8000/api/invoice/byid/1', 1, '192.168.8.189', '2020-10-23 22:50:55', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 04:20:55'),
(381, NULL, NULL, 'SELLER_ONLY', 'http://192.168.8.189:8000/api/invoice/delivery/1', 'App\\Http\\Controllers\\Invoice\\InvoiceController', 'update', 'http://192.168.8.189:8000/api/invoice/delivery/1', 0, '192.168.8.189', '2020-10-23 23:32:25', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 05:02:25'),
(383, NULL, NULL, 'INVOICE_CAN_NOT_UPDATE', 'http://192.168.8.189:8000/api/invoice/delivery/1', 'App\\Http\\Controllers\\Invoice\\InvoiceController', 'update', 'http://192.168.8.189:8000/api/invoice/delivery/1', 0, '192.168.8.189', '2020-10-23 23:37:28', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 05:07:28'),
(385, NULL, NULL, 'INVOICE_CAN_NOT_UPDATE', 'http://192.168.8.189:8000/api/invoice/delivery/1', 'App\\Http\\Controllers\\Invoice\\InvoiceController', 'update', 'http://192.168.8.189:8000/api/invoice/delivery/1', 0, '192.168.8.189', '2020-10-23 23:37:49', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 05:07:49'),
(386, NULL, NULL, 'view data of the given role seller', 'http://192.168.8.189:8000/api/invoice/1', 'App\\Http\\Controllers\\Invoice\\InvoiceController', 'delete', 'http://192.168.8.189:8000/api/invoice/1', 1, '192.168.8.189', '2020-10-24 03:20:57', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 08:50:57'),
(387, NULL, NULL, 'invoice cancel success id - 1', 'http://192.168.8.189:8000/api/invoice/1', 'App\\Http\\Controllers\\Invoice\\InvoiceController', 'delete', 'http://192.168.8.189:8000/api/invoice/1', 1, '192.168.8.189', '2020-10-24 03:20:57', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 08:50:57'),
(388, NULL, NULL, 'view data of the given role seller', 'http://192.168.8.189:8000/api/invoice/1', 'App\\Http\\Controllers\\Invoice\\InvoiceController', 'delete', 'http://192.168.8.189:8000/api/invoice/1', 1, '192.168.8.189', '2020-10-24 03:21:26', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 08:51:26'),
(389, NULL, NULL, 'invoice cancel success id - 1', 'http://192.168.8.189:8000/api/invoice/1', 'App\\Http\\Controllers\\Invoice\\InvoiceController', 'delete', 'http://192.168.8.189:8000/api/invoice/1', 1, '192.168.8.189', '2020-10-24 03:21:26', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 08:51:26'),
(390, NULL, NULL, 'view data of the given role seller', 'http://192.168.8.189:8000/api/invoice/1', 'App\\Http\\Controllers\\Invoice\\InvoiceController', 'delete', 'http://192.168.8.189:8000/api/invoice/1', 1, '192.168.8.189', '2020-10-24 03:23:28', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 08:53:28'),
(391, NULL, NULL, 'invoice cancel success id - 1', 'http://192.168.8.189:8000/api/invoice/1', 'App\\Http\\Controllers\\Invoice\\InvoiceController', 'delete', 'http://192.168.8.189:8000/api/invoice/1', 1, '192.168.8.189', '2020-10-24 03:23:28', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 08:53:28'),
(393, NULL, NULL, 'BUYER_ONLY', 'http://192.168.8.189:8000/api/invoice/invoiceitems', 'App\\Http\\Controllers\\Invoice\\InvoiceItemsController', 'create', 'http://192.168.8.189:8000/api/invoice/invoiceitems', 0, '192.168.8.189', '2020-10-24 03:53:38', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 09:23:38'),
(395, NULL, NULL, 'The given data was invalid.', 'http://192.168.8.189:8000/api/invoice/invoiceitems', 'App\\Http\\Controllers\\Invoice\\InvoiceItemsController', 'create', 'http://192.168.8.189:8000/api/invoice/invoiceitems', 0, '192.168.8.189', '2020-10-24 03:53:57', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 09:23:57'),
(397, NULL, NULL, 'SQLSTATE[42S22]: Column not found: 1054 Unknown column \'quatity\' in \'field list\' (SQL: insert into `inv_items` (`inv_id`, `product_id`, `quatity`, `default_image`, `product_images`, `created_at`, `updated_at`) values (1, 2, ?, ?, ?, 2020-10-24 09:24:24, 2020-10-24 09:24:24))', 'http://192.168.8.189:8000/api/invoice/invoiceitems', 'App\\Http\\Controllers\\Invoice\\InvoiceItemsController', 'create', 'http://192.168.8.189:8000/api/invoice/invoiceitems', 0, '192.168.8.189', '2020-10-24 03:54:24', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 09:24:24'),
(398, NULL, NULL, 'view data of the given role buyer', 'http://192.168.8.189:8000/api/invoice/invoiceitems', 'App\\Http\\Controllers\\Invoice\\InvoiceItemsController', 'create', 'http://192.168.8.189:8000/api/invoice/invoiceitems', 1, '192.168.8.189', '2020-10-24 03:56:01', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 09:26:01'),
(399, NULL, NULL, 'invoice items created for : 1', 'http://192.168.8.189:8000/api/invoice/invoiceitems', 'App\\Http\\Controllers\\Invoice\\InvoiceItemsController', 'create', 'http://192.168.8.189:8000/api/invoice/invoiceitems', 1, '192.168.8.189', '2020-10-24 03:56:01', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 09:26:01'),
(400, NULL, NULL, 'view data of the given role buyer', 'http://192.168.8.189:8000/api/invoice', 'App\\Http\\Controllers\\Invoice\\InvoiceController', 'getAllInvoices', 'http://192.168.8.189:8000/api/invoice', 1, '192.168.8.189', '2020-10-24 03:56:43', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 09:26:43'),
(401, NULL, NULL, 'view all data invoices', 'http://192.168.8.189:8000/api/invoice', 'App\\Http\\Controllers\\Invoice\\InvoiceController', 'getAllInvoices', 'http://192.168.8.189:8000/api/invoice', 1, '192.168.8.189', '2020-10-24 03:56:43', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 09:26:43'),
(402, NULL, NULL, 'view data of the given invoice 1', 'http://192.168.8.189:8000/api/invoice/byid/1', 'App\\Http\\Controllers\\Invoice\\InvoiceController', 'getById', 'http://192.168.8.189:8000/api/invoice/byid/1', 1, '192.168.8.189', '2020-10-24 03:57:09', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 09:27:09'),
(403, NULL, NULL, 'view data of the given invoice items 1', 'http://192.168.8.189:8000/api/invoice/invoiceitems/byid/1', 'App\\Http\\Controllers\\Invoice\\InvoiceItemsController', 'getById', 'http://192.168.8.189:8000/api/invoice/invoiceitems/byid/1', 1, '192.168.8.189', '2020-10-24 03:59:19', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 09:29:19'),
(405, NULL, NULL, 'ONLY_PENDING_INVOICE_ITEMS_CAN_BE_UPDATED', 'http://192.168.8.189:8000/api/invoice/invoiceitems/1', 'App\\Http\\Controllers\\Invoice\\InvoiceItemsController', 'update', 'http://192.168.8.189:8000/api/invoice/invoiceitems/1', 0, '192.168.8.189', '2020-10-24 04:20:57', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 09:50:57'),
(407, NULL, NULL, 'ONLY_PENDING_INVOICE_ITEMS_CAN_BE_UPDATED', 'http://192.168.8.189:8000/api/invoice/invoiceitems/1', 'App\\Http\\Controllers\\Invoice\\InvoiceItemsController', 'update', 'http://192.168.8.189:8000/api/invoice/invoiceitems/1', 0, '192.168.8.189', '2020-10-24 04:21:21', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 09:51:21'),
(409, NULL, NULL, 'view data of the given role buyer', 'http://192.168.8.189:8000/api/invoice/invoiceitems/1', 'App\\Http\\Controllers\\Invoice\\InvoiceItemsController', 'update', 'http://192.168.8.189:8000/api/invoice/invoiceitems/1', 1, '192.168.8.189', '2020-10-24 04:22:59', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 09:52:59'),
(410, NULL, NULL, 'Invoice item update product_id: 2', 'http://192.168.8.189:8000/api/invoice/invoiceitems/1', 'App\\Http\\Controllers\\Invoice\\InvoiceItemsController', 'update', 'http://192.168.8.189:8000/api/invoice/invoiceitems/1', 1, '192.168.8.189', '2020-10-24 04:22:59', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 09:52:59'),
(412, NULL, NULL, 'ONLY_PENDING_INVOICE_ITEMS_CAN_BE_DELETED', 'http://192.168.8.189:8000/api/invoice/invoiceitems/1', 'App\\Http\\Controllers\\Invoice\\InvoiceItemsController', 'delete', 'http://192.168.8.189:8000/api/invoice/invoiceitems/1', 0, '192.168.8.189', '2020-10-24 04:25:09', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 09:55:09'),
(413, NULL, NULL, 'view data of the given role buyer', 'http://192.168.8.189:8000/api/invoice/invoiceitems/1', 'App\\Http\\Controllers\\Invoice\\InvoiceItemsController', 'delete', 'http://192.168.8.189:8000/api/invoice/invoiceitems/1', 1, '192.168.8.189', '2020-10-24 04:25:27', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 09:55:27'),
(414, NULL, NULL, 'product delete success id - 1', 'http://192.168.8.189:8000/api/invoice/invoiceitems/1', 'App\\Http\\Controllers\\Invoice\\InvoiceItemsController', 'delete', 'http://192.168.8.189:8000/api/invoice/invoiceitems/1', 1, '192.168.8.189', '2020-10-24 04:25:27', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 09:55:27'),
(416, NULL, NULL, 'Property [complete_status] does not exist on this collection instance.', 'http://192.168.8.189:8000/api/invoice/invoiceitems', 'App\\Http\\Controllers\\Invoice\\InvoiceItemsController', 'create', 'http://192.168.8.189:8000/api/invoice/invoiceitems', 0, '192.168.8.189', '2020-10-24 04:25:42', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 09:55:42'),
(420, NULL, NULL, 'Undefined variable: child', 'http://192.168.8.189:8000/api/invoice/invoiceitems', 'App\\Http\\Controllers\\Invoice\\InvoiceItemsController', 'create', 'http://192.168.8.189:8000/api/invoice/invoiceitems', 0, '192.168.8.189', '2020-10-24 04:27:16', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 09:57:16'),
(423, NULL, NULL, 'view data of the given role buyer', 'http://192.168.8.189:8000/api/invoice/invoiceitems', 'App\\Http\\Controllers\\Invoice\\InvoiceItemsController', 'create', 'http://192.168.8.189:8000/api/invoice/invoiceitems', 1, '192.168.8.189', '2020-10-24 04:28:12', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 09:58:12'),
(424, NULL, NULL, 'invoice items created for : 1', 'http://192.168.8.189:8000/api/invoice/invoiceitems', 'App\\Http\\Controllers\\Invoice\\InvoiceItemsController', 'create', 'http://192.168.8.189:8000/api/invoice/invoiceitems', 1, '192.168.8.189', '2020-10-24 04:28:12', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 09:58:12'),
(426, NULL, NULL, 'INVOICE_ITEMS_ALREADY_AVAILABLE', 'http://192.168.8.189:8000/api/invoice/invoiceitems', 'App\\Http\\Controllers\\Invoice\\InvoiceItemsController', 'create', 'http://192.168.8.189:8000/api/invoice/invoiceitems', 0, '192.168.8.189', '2020-10-24 04:28:19', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 09:58:19'),
(430, NULL, NULL, 'INVOICE_ITEM_ALREADY_AVAILABLE', 'http://192.168.8.189:8000/api/invoice/invoiceitems', 'App\\Http\\Controllers\\Invoice\\InvoiceItemsController', 'create', 'http://192.168.8.189:8000/api/invoice/invoiceitems', 0, '192.168.8.189', '2020-10-24 04:31:59', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 10:01:59'),
(432, NULL, NULL, 'SELLER_ONLY', 'http://192.168.8.189:8000/api/invoice/1', 'App\\Http\\Controllers\\Invoice\\InvoiceController', 'delete', 'http://192.168.8.189:8000/api/invoice/1', 0, '192.168.8.189', '2020-10-24 05:05:55', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 10:35:55'),
(433, NULL, NULL, 'view data of the given role seller', 'http://192.168.8.189:8000/api/invoice/1', 'App\\Http\\Controllers\\Invoice\\InvoiceController', 'delete', 'http://192.168.8.189:8000/api/invoice/1', 1, '192.168.8.189', '2020-10-24 05:06:23', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 10:36:23'),
(434, NULL, NULL, 'invoice cancel success id - 1', 'http://192.168.8.189:8000/api/invoice/1', 'App\\Http\\Controllers\\Invoice\\InvoiceController', 'delete', 'http://192.168.8.189:8000/api/invoice/1', 1, '192.168.8.189', '2020-10-24 05:06:23', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 10:36:23'),
(436, NULL, NULL, 'INVOICE_NOT_COMPLETED', 'http://192.168.8.189:8000/api/invoice/delivery/1', 'App\\Http\\Controllers\\Invoice\\InvoiceController', 'delivered', 'http://192.168.8.189:8000/api/invoice/delivery/1', 0, '192.168.8.189', '2020-10-24 05:09:25', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 10:39:25'),
(437, NULL, NULL, 'view data of the given role seller', 'http://192.168.8.189:8000/api/invoice/changestatus/1', 'App\\Http\\Controllers\\Invoice\\InvoiceController', 'update', 'http://192.168.8.189:8000/api/invoice/changestatus/1', 1, '192.168.8.189', '2020-10-24 05:09:54', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 10:39:54'),
(438, NULL, NULL, 'invoice complete_status changed invoice id : 1 ,invoice id1', 'http://192.168.8.189:8000/api/invoice/changestatus/1', 'App\\Http\\Controllers\\Invoice\\InvoiceController', 'update', 'http://192.168.8.189:8000/api/invoice/changestatus/1', 1, '192.168.8.189', '2020-10-24 05:09:54', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 10:39:54'),
(440, NULL, NULL, 'INVOICE_NOT_PENDING', 'http://192.168.8.189:8000/api/invoice/changestatus/1', 'App\\Http\\Controllers\\Invoice\\InvoiceController', 'update', 'http://192.168.8.189:8000/api/invoice/changestatus/1', 0, '192.168.8.189', '2020-10-24 05:11:13', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 10:41:13'),
(441, NULL, NULL, 'view data of the given role seller', 'http://192.168.8.189:8000/api/invoice/changestatus/1', 'App\\Http\\Controllers\\Invoice\\InvoiceController', 'update', 'http://192.168.8.189:8000/api/invoice/changestatus/1', 1, '192.168.8.189', '2020-10-24 05:11:48', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 10:41:48'),
(442, NULL, NULL, 'invoice complete_status changed invoice id : 1 ,invoice id1', 'http://192.168.8.189:8000/api/invoice/changestatus/1', 'App\\Http\\Controllers\\Invoice\\InvoiceController', 'update', 'http://192.168.8.189:8000/api/invoice/changestatus/1', 1, '192.168.8.189', '2020-10-24 05:11:48', 'sample time diff', '0', 'default', 'PostmanRuntime/7.26.5', '00', '00', '2020-10-24 10:41:48');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `inv_invoice`
--
ALTER TABLE `inv_invoice`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inv_items`
--
ALTER TABLE `inv_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `inv_id` (`inv_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `pr_category`
--
ALTER TABLE `pr_category`
  ADD PRIMARY KEY (`id`),
  ADD KEY `super_cat_id` (`super_cat_id`);

--
-- Indexes for table `pr_product`
--
ALTER TABLE `pr_product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `owner_id` (`owner_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `pr_product_info`
--
ALTER TABLE `pr_product_info`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `seller_details`
--
ALTER TABLE `seller_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `role_id` (`role_id`);

--
-- Indexes for table `user_activities`
--
ALTER TABLE `user_activities`
  ADD PRIMARY KEY (`id`),
  ADD KEY `UIDX` (`uidx`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `inv_invoice`
--
ALTER TABLE `inv_invoice`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'A', AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `inv_items`
--
ALTER TABLE `inv_items`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT for table `pr_category`
--
ALTER TABLE `pr_category`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'primary key', AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `pr_product`
--
ALTER TABLE `pr_product`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'AUTO_INCREMENT', AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `pr_product_info`
--
ALTER TABLE `pr_product_info`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `seller_details`
--
ALTER TABLE `seller_details`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Auto Increment number', AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `user_activities`
--
ALTER TABLE `user_activities`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Log ID (Auto Increment)', AUTO_INCREMENT=443;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `inv_items`
--
ALTER TABLE `inv_items`
  ADD CONSTRAINT `inv_items_ibfk_1` FOREIGN KEY (`inv_id`) REFERENCES `inv_invoice` (`id`);

--
-- Constraints for table `pr_category`
--
ALTER TABLE `pr_category`
  ADD CONSTRAINT `pr_category_ibfk_1` FOREIGN KEY (`super_cat_id`) REFERENCES `pr_category` (`id`);

--
-- Constraints for table `pr_product`
--
ALTER TABLE `pr_product`
  ADD CONSTRAINT `pr_product_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `pr_category` (`id`);

--
-- Constraints for table `pr_product_info`
--
ALTER TABLE `pr_product_info`
  ADD CONSTRAINT `pr_product_info_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `pr_product` (`id`);

--
-- Constraints for table `seller_details`
--
ALTER TABLE `seller_details`
  ADD CONSTRAINT `seller_details_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
